package com.kms.katalon.core.testng.keyword.internal;

import org.testng.ITestNGListener;
import org.testng.TestListenerAdapter;

public class CustomTestNGListener extends TestListenerAdapter implements ITestNGListener {

}