package com.kms.katalon.core.webui.driver.bidi;

import com.kms.katalon.core.logging.KeywordLogger;
import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.util.FileUtil;
import com.kms.katalon.selenium.constant.SeleniumW3CCapabilityConstant;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.HasBiDi;
import org.openqa.selenium.bidi.module.Script;

import java.io.File;
import java.io.IOException;

public class BiDiDriverUtil {
    protected static final KeywordLogger logger = KeywordLogger.getInstance(DriverFactory.class);

    private static final String SMART_LOCATOR_ADDON_RELATIVE_PATH = "scripts";
    private static final String SMART_WAIT_ADDON_RELATIVE_PATH = "scripts";

    public static boolean hasBiDiCapability(Capabilities capabilities) {
        return capabilities.getCapability(SeleniumW3CCapabilityConstant.WEB_SOCKET_URL_CAP) != null;
    }

    public static boolean getBiDiCapability(Capabilities capabilities) {
        Boolean value = (Boolean) capabilities.getCapability(SeleniumW3CCapabilityConstant.WEB_SOCKET_URL_CAP);
        return value != null && value;
    }

    public static boolean tryInjectingSmartWaitScript(WebDriver driver) {
        if (driver instanceof HasBiDi hasBiDiWebDriver && hasBiDiWebDriver.maybeGetBiDi().isPresent()) {
            try {
                BiDiDriverUtil.injectSmartWaitScript(driver);
                return true;
            } catch (IOException e) {
                logger.logInfo(e.getMessage());
                return false;
            }
        } else {
            logger.logWarning("Your browser version or type does not support "
                    + "the BiDirectional WebDriver Protocol which is required for Smart Wait functionality. "
                    + "Please update your browser or switch to a compatible one.");
            return false;
        }
    }

    public static boolean tryInjectingSmartLocator(WebDriver driver) {
        if (driver instanceof HasBiDi hasBiDiWebDriver && hasBiDiWebDriver.maybeGetBiDi().isPresent()) {
            try {
                BiDiDriverUtil.injectSmartLocatorScript(driver);
                return true;
            } catch (IOException e) {
                logger.logInfo(e.getMessage());
                return false;
            }
        } else {
            logger.logWarning("Your browser version or type does not support "
                    + "the BiDirectional WebDriver Protocol which is required for Smart Locator functionality. "
                    + "Please update your browser or switch to a compatible one.");
            return false;
        }
    }

    public static void injectSmartWaitScript(WebDriver driver) throws IOException {
        File smartWaitFolder = new File(FileUtil.getExtensionsDirectory(), SMART_WAIT_ADDON_RELATIVE_PATH);

        File smartWaitScriptFile = new File(smartWaitFolder, "smart-wait.js");
        String smartWaitScript = FileUtils.readFileToString(smartWaitScriptFile, "UTF-8");

        try (Script script = new Script(driver)) {
            System.out.println("Preloading smart wait");
            script.addPreloadScript("() => {" + smartWaitScript + "}");
            script.addPreloadScript("console.log('Injected Smart Wait successfully')");
        }
    }

    public static void injectSmartLocatorScript(WebDriver driver) throws IOException {
        File smartLocatorFolder = new File(FileUtil.getExtensionsDirectory(), SMART_LOCATOR_ADDON_RELATIVE_PATH);

        File smartLocator = new File(smartLocatorFolder, "smart-locator.js");
        String smartLocatorScript = FileUtils.readFileToString(smartLocator, "UTF-8");

        File smartLocatorBundleFile = new File(smartLocatorFolder, "smart-locator-bundle.js");
        String smartLocatorBundleScript = FileUtils.readFileToString(smartLocatorBundleFile, "UTF-8");

        try (Script script = new Script(driver)) {
            System.out.println("Preloading smart locator");
            script.addPreloadScript("() => {" + smartLocatorBundleScript + "}");
            script.addPreloadScript("() => {" + smartLocatorScript + "}");
            script.addPreloadScript("console.log('Injected Smart Locator successfully')");
        }
    }
}
