package com.kms.katalon.core.webui.driver.chrome;

import com.kms.katalon.core.configuration.RunConfiguration;
import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.driver.remote.AbstractRemoteDriverBuilder;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

public class ChromeRemoteDriverBuilder extends AbstractRemoteDriverBuilder {

    @Override
    protected AbstractDriverOptions<?> createOptions(Capabilities capabilities) {
        return new ChromeOptions().merge(capabilities);
    }

    @Override
    protected WebDriver createDriver(AbstractDriverOptions<?> options) throws Exception {
        if (!(options instanceof ChromeOptions chromeOptions)) {
            return null;
        }

        var debugHost = RunConfiguration.getDriverSystemProperty(DriverFactory.WEB_UI_DRIVER_PROPERTY, DriverFactory.DEBUG_HOST,
                DriverFactory.DEFAULT_DEBUG_HOST);
        var debugPort = RunConfiguration.getDriverSystemProperty(DriverFactory.WEB_UI_DRIVER_PROPERTY, DriverFactory.DEBUG_PORT,
                DriverFactory.DEFAULT_CHROME_DEBUG_PORT);
        chromeOptions.setExperimentalOption("debuggerAddress", debugHost + ":" + debugPort);

        var driverPort = determineNextFreePort(9515);
        var driverUrl = new URL("http", debugHost, driverPort, "/");

        Runtime.getRuntime().exec(new String[] {
                System.getProperty(DriverFactory.CHROME_DRIVER_PATH_PROPERTY_KEY),
                "--port=" + driverPort
        });

        waitForRemoteBrowserReady(driverUrl);

        System.setProperty(DriverFactory.CHROME_DRIVER_PATH_PROPERTY_KEY, ChromeDriverUtil.getChromeDriverPath());
        return new RemoteWebDriver(driverUrl, chromeOptions);
    }
}
