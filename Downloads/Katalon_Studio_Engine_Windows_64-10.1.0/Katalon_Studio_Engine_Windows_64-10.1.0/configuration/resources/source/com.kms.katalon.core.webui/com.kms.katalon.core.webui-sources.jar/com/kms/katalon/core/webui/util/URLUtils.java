package com.kms.katalon.core.webui.util;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;

public class URLUtils {

    public static String removeCrendentialsFromURL(String urlWithCredentials) {
        try {
            URL url = new URL(urlWithCredentials);
            return url.getHost() + url.getPath();
        } catch (MalformedURLException e) {
            return StringUtils.EMPTY;
        }
    }
}
