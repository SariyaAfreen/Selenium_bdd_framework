package com.kms.katalon.core.webui.driver;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;

public interface IDriverBuilder {

    IDriverBuilder capabilities(Capabilities capabilities);

    IDriverBuilder withSmartWait(boolean value);

    IDriverBuilder withSmartLocator(boolean value);

    WebDriver build() throws Exception;
}
