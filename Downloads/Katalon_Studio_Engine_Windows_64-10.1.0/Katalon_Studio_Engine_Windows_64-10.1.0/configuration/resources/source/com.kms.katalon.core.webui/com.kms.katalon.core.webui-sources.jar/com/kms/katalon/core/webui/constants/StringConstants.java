package com.kms.katalon.core.webui.constants;

public class StringConstants extends com.kms.katalon.core.constants.StringConstants {
    // EngineLogger
    public static final String COMM_EXC_UNABLE_TO_INIT_RESRC_BUNDLE = CoreWebuiMessageConstants.COMM_EXC_UNABLE_TO_INIT_RESRC_BUNDLE;

    public static final String COMM_EXC_RESRC_BUNDLE_IS_NOT_INIT = CoreWebuiMessageConstants.COMM_EXC_RESRC_BUNDLE_IS_NOT_INIT;

    // EUtil
    public static final String COMM_MSG_FAILED_TO_EXEC_COMMAND = CoreWebuiMessageConstants.COMM_MSG_FAILED_TO_EXEC_COMMAND;

    public static final String COMM_MSG_EXC_ERROR = CoreWebuiMessageConstants.COMM_MSG_EXC_ERROR;

    public static final String COMM_EXC_TEXT_VAL_CANNOT_BE_NULL = CoreWebuiMessageConstants.COMM_EXC_TEXT_VAL_CANNOT_BE_NULL;

    public static final String COMM_EXC_CONTAIN_TEXT_VAL_CANNOT_BE_NULL = CoreWebuiMessageConstants.COMM_EXC_CONTAIN_TEXT_VAL_CANNOT_BE_NULL;

    // EWindow
    public static final String COMM_EXC_FAILED_TO_GET_URL = CoreWebuiMessageConstants.COMM_EXC_FAILED_TO_GET_URL;

    public static final String COMM_EXC_URL_DOES_NOT_CONTAIN = CoreWebuiMessageConstants.COMM_EXC_URL_DOES_NOT_CONTAIN;

    // WebUiCommonHelper
    public static final String COMM_EXC_CHECKING_TEXT_PRESENT = CoreWebuiMessageConstants.COMM_EXC_CHECKING_TEXT_PRESENT;

    public static final String COMM_EXC_TEXT_IS_NULL = CoreWebuiMessageConstants.COMM_EXC_TEXT_IS_NULL;

    public static final String COMM_LOG_INFO_FINDING_TEXT_ON_PAGE = CoreWebuiMessageConstants.COMM_LOG_INFO_FINDING_TEXT_ON_PAGE;

    public static final String COMM_LOG_INFO_CHECKING_INDEX_PARAMS = CoreWebuiMessageConstants.COMM_LOG_INFO_CHECKING_INDEX_PARAMS;

    public static final String COMM_EXC_INVALID_INDEX = CoreWebuiMessageConstants.COMM_EXC_INVALID_INDEX;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_LBL_PRESENT_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_LBL_PRESENT_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_W_LBL_IS_PRESENT = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_W_LBL_IS_PRESENT;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_VAL_PRESENT_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_VAL_PRESENT_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_W_VAL_IS_PRESENT = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_W_VAL_IS_PRESENT;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_LBL_SELECTED_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_LBL_SELECTED_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_W_LBL_IS_SELECTED = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_W_LBL_IS_SELECTED;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_LBL_NOT_SELECTED_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_LBL_NOT_SELECTED_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_W_LBL_IS_NOT_SELECTED = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_W_LBL_IS_NOT_SELECTED;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_VAL_SELECTED_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_VAL_SELECTED_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_W_VAL_IS_SELECTED = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_W_VAL_IS_SELECTED;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_VAL_NOT_SELECTED_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_VAL_NOT_SELECTED_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_W_VAL_IS_NOT_SELECTED = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_W_VAL_IS_NOT_SELECTED;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_INDEX_RANGE_SELECTED_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_INDEX_RANGE_SELECTED_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_IS_SELECTED = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_IS_SELECTED;

    public static final String COMM_LOG_INFO_COUNTING_NUM_OPTS_W_INDEX_RANGE_NOT_SELECTED_ON_OBJ = CoreWebuiMessageConstants.COMM_LOG_INFO_COUNTING_NUM_OPTS_W_INDEX_RANGE_NOT_SELECTED_ON_OBJ;

    public static final String COMM_LOG_INFO_OPT_AT_INDEX_IS_NOT_SELECTED = CoreWebuiMessageConstants.COMM_LOG_INFO_OPT_AT_INDEX_IS_NOT_SELECTED;

    // ScreenUtil
    public static final String COMM_EXC_CANNOT_RECOGNIZE_IMG_ON_SCREEN = CoreWebuiMessageConstants.COMM_EXC_CANNOT_RECOGNIZE_IMG_ON_SCREEN;

    public static final String COMM_EXC_IMG_FILE_DOES_NOT_EXIST = CoreWebuiMessageConstants.COMM_EXC_IMG_FILE_DOES_NOT_EXIST;

    public static final String COMM_EXC_BROWSER_IS_NOT_SUPPORTED = CoreWebuiMessageConstants.COMM_EXC_BROWSER_IS_NOT_SUPPORTED;

    // WebUiKeywordContributor
    public static final String CONTR_LBL_WEB_UI_KEYWORD = CoreWebuiMessageConstants.CONTR_LBL_WEB_UI_KEYWORD;

    // DriverFactory
    public static final String DRI_LOG_WARNING_BROWSER_ALREADY_OPENED = CoreWebuiMessageConstants.DRI_LOG_WARNING_BROWSER_ALREADY_OPENED;

    public static final String DRI_LOG_WARNING_BROWSER_NOT_REACHABLE = CoreWebuiMessageConstants.DRI_LOG_WARNING_BROWSER_NOT_REACHABLE;

    public static final String DRI_MSG_UNABLE_REACH_WEB_DRI_TIMEOUT = CoreWebuiMessageConstants.DRI_MSG_UNABLE_REACH_WEB_DRI_TIMEOUT;

    public static final String DRI_ERROR_MSG_NO_BROWSER_SET = CoreWebuiMessageConstants.DRI_ERROR_MSG_NO_BROWSER_SET;

    public static final String DRI_ERROR_DRIVER_X_NOT_IMPLEMENTED = CoreWebuiMessageConstants.DRI_ERROR_DRIVER_X_NOT_IMPLEMENTED;

    public static final String DRI_MISSING_PROPERTY_X_FOR_APPIUM_REMOTE_WEB_DRIVER = CoreWebuiMessageConstants.DRI_MISSING_PROPERTY_X_FOR_APPIUM_REMOTE_WEB_DRIVER;

    public static final String DRI_PLATFORM_NAME_X_IS_NOT_SUPPORTED_FOR_APPIUM_REMOTE_WEB_DRIVER = CoreWebuiMessageConstants.DRI_PLATFORM_NAME_X_IS_NOT_SUPPORTED_FOR_APPIUM_REMOTE_WEB_DRIVER;

    public static final String CONF_PROPERTY_IE_DRIVER_PATH = "ieDriverPath";

    public static final String CONF_PROPERTY_EDGE_DRIVER_PATH = "edgeDriverPath";

    public static final String CONF_PROPERTY_CHROME_DRIVER_PATH = "chromeDriverPath";

    public static final String CONF_PROPERTY_GECKO_DRIVER_PATH = "geckoDriverPath";

    public static final String CONF_PROPERTY_EDGE_CHROMIUM_DRIVER_PATH = "edgeChromiumDriverPath";

    public static final String CONF_PROPERTY_WAIT_FOR_IE_HANGING = "waitForIEHanging";

    public static final String CONF_PROPERTY_ENABLE_PAGE_LOAD_TIMEOUT = "enablePageLoadTimeout";

    public static final String CONF_PROPERTY_DEFAULT_PAGE_LOAD_TIMEOUT = "defaultPageLoadTimeout";

    public static final String CONF_PROPERTY_ACTION_DELAY = "actionDelay";

    public static final String CONF_PROPERTY_USE_ACTION_DELAY_IN_SECOND = "useActionDelayInSecond";

    public static final String CONF_PROPERTY_IGNORE_PAGE_LOAD_TIMEOUT_EXCEPTION = "ignorePageLoadTimeoutException";

    public static final String CONF_PROPERTY_EXECUTED_BROWSER = XML_LOG_BROWSER_TYPE_PROPERTY;

    public static final String CONF_PROPERTY_REMOTE_WEB_DRIVER_URL = "remoteWebDriverUrl";

    public static final String CONF_PROPERTY_REMOTE_WEB_DRIVER_TYPE = "remoteWebDriverType";

    public static final String XML_LOG_STARTING_DRIVER_X = CoreWebuiMessageConstants.XML_LOG_STARTING_DRIVER_X;

    public static final String XML_LOG_CONNECTING_TO_REMOTE_WEB_SERVER_X_WITH_TYPE_Y = CoreWebuiMessageConstants.XML_LOG_CONNECTING_TO_REMOTE_WEB_SERVER_X_WITH_TYPE_Y;

    public static final String XML_LOG_ERROR_BROWSER_NOT_IE = CoreWebuiMessageConstants.XML_LOG_ERROR_BROWSER_NOT_IE;

    public static final String XML_LOG_ERROR_CANNOT_FOUND_WINDOW_HANDLE = CoreWebuiMessageConstants.XML_LOG_ERROR_CANNOT_FOUND_WINDOW_HANDLE;

    public static final String XML_LOG_SELENIUM_VERSION = "seleniumVersion";

    // BrowserNotOpenedException

    public static final String BROWSER_CAPABILITY_NAME = "browser";

    public static final String EXC_BROWSER_IS_NOT_OPENED = CoreWebuiMessageConstants.EXC_BROWSER_IS_NOT_OPENED;

    // WebElementNotFoundException
    public static final String EXC_WEB_ELEMENT_NOT_FOUND = CoreWebuiMessageConstants.EXC_WEB_ELEMENT_NOT_FOUND;

    // WebUiBuiltInKeywords
    public static final String KW_LOG_INFO_OPENING_BROWSER = CoreWebuiMessageConstants.KW_LOG_INFO_OPENING_BROWSER;

    public static final String KW_LOG_INFO_NAVIGATING_BROWSER_TO = CoreWebuiMessageConstants.KW_LOG_INFO_NAVIGATING_BROWSER_TO;

    public static final String KW_LOG_PASSED_BROWSER_IS_OPENED_W_URL = CoreWebuiMessageConstants.KW_LOG_PASSED_BROWSER_IS_OPENED_W_URL;

    public static final String KW_MSG_UNABLE_TO_OPEN_BROWSER_W_URL = CoreWebuiMessageConstants.KW_MSG_UNABLE_TO_OPEN_BROWSER_W_URL;

    public static final String KW_MSG_UNABLE_TO_OPEN_BROWSER = CoreWebuiMessageConstants.KW_MSG_UNABLE_TO_OPEN_BROWSER;

    public static final String KW_LOG_INFO_CLOSING_BROWSER = CoreWebuiMessageConstants.KW_LOG_INFO_CLOSING_BROWSER;

    public static final String KW_LOG_PASSED_BROWSER_IS_CLOSED = CoreWebuiMessageConstants.KW_LOG_PASSED_BROWSER_IS_CLOSED;

    public static final String KW_MSG_UNABLE_TO_CLOSE_BROWSER = CoreWebuiMessageConstants.KW_MSG_UNABLE_TO_CLOSE_BROWSER;

    public static final String KW_LOG_INFO_NAVIGATING_BACK = CoreWebuiMessageConstants.KW_LOG_INFO_NAVIGATING_BACK;

    public static final String KW_LOG_PASSED_NAVIGATE_BACK = CoreWebuiMessageConstants.KW_LOG_PASSED_NAVIGATE_BACK;

    public static final String KW_MSG_CANNOT_BACK_TO_PREV_PAGE = CoreWebuiMessageConstants.KW_MSG_CANNOT_BACK_TO_PREV_PAGE;

    public static final String KW_LOG_INFO_NAVIGATING_FORWARD = CoreWebuiMessageConstants.KW_LOG_INFO_NAVIGATING_FORWARD;

    public static final String KW_LOG_PASSED_NAVIGATE_FORWARD = CoreWebuiMessageConstants.KW_LOG_PASSED_NAVIGATE_FORWARD;

    public static final String KW_MSG_CANNOT_FORWARD_TO_NEXT_PAGE = CoreWebuiMessageConstants.KW_MSG_CANNOT_FORWARD_TO_NEXT_PAGE;

    public static final String KW_LOG_INFO_REFRESHING = CoreWebuiMessageConstants.KW_LOG_INFO_REFRESHING;

    public static final String KW_LOG_PASSED_REFRESH = CoreWebuiMessageConstants.KW_LOG_PASSED_REFRESH;

    public static final String KW_MSG_CANNOT_REFRESH_PAGE = CoreWebuiMessageConstants.KW_MSG_CANNOT_REFRESH_PAGE;

    public static final String KW_LOG_INFO_CHECKING_URL = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_URL;

    public static final String KW_EXC_URL_CANNOT_BE_NULL_OR_EMPTY = CoreWebuiMessageConstants.KW_EXC_URL_CANNOT_BE_NULL_OR_EMPTY;

    public static final String KW_EXC_URL_IS_NULL = CoreWebuiMessageConstants.KW_EXC_URL_IS_NULL;

    public static final String KW_LOG_INFO_NAVIGATING_TO = CoreWebuiMessageConstants.KW_LOG_INFO_NAVIGATING_TO;

    public static final String KW_LOG_PASSED_NAVIGATE_TO = CoreWebuiMessageConstants.KW_LOG_PASSED_NAVIGATE_TO;

    public static final String KW_MSG_CANNOT_NAVIGATE_TO = CoreWebuiMessageConstants.KW_MSG_CANNOT_NAVIGATE_TO;

    public static final String KW_LOG_PASSED_NEW_TAB_AND_NAVIGATE_TO = CoreWebuiMessageConstants.KW_LOG_PASSED_NEW_TAB_AND_NAVIGATE_TO;

    public static final String KW_MSG_CANNOT_NEW_TAB_AND_NAVIGATE_TO = CoreWebuiMessageConstants.KW_MSG_CANNOT_NEW_TAB_AND_NAVIGATE_TO;

    public static final String KW_LOG_INFO_GETTING_CURR_WINDOW_TITLE = CoreWebuiMessageConstants.KW_LOG_INFO_GETTING_CURR_WINDOW_TITLE;

    public static final String KW_LOG_PASSED_CURR_WINDOW_TITLE = CoreWebuiMessageConstants.KW_LOG_PASSED_CURR_WINDOW_TITLE;

    public static final String KW_MSG_CANNOT_GET_CURR_WINDOW_TITLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_CURR_WINDOW_TITLE;

    public static final String KW_LOG_INFO_GETTING_CURR_WINDOW_URL = CoreWebuiMessageConstants.KW_LOG_INFO_GETTING_CURR_WINDOW_URL;

    public static final String KW_LOG_PASSED_CURR_WINDOW_URL = CoreWebuiMessageConstants.KW_LOG_PASSED_CURR_WINDOW_URL;

    public static final String KW_MSG_CANNOT_GET_CURR_WINDOW_URL = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_CURR_WINDOW_URL;

    public static final String KW_LOG_INFO_GETTING_CURR_WINDOW_INDEX = CoreWebuiMessageConstants.KW_LOG_INFO_GETTING_CURR_WINDOW_INDEX;

    public static final String KW_LOG_PASSED_CURR_WINDOW_INDEX = CoreWebuiMessageConstants.KW_LOG_PASSED_CURR_WINDOW_INDEX;

    public static final String KW_MSG_CANNOT_GET_CURR_WINDOW_INDEX = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_CURR_WINDOW_INDEX;

    public static final String KW_LOG_INFO_MAX_CURR_WINDOW = CoreWebuiMessageConstants.KW_LOG_INFO_MAX_CURR_WINDOW;

    public static final String KW_LOG_PASSED_MAX_CURR_WINDOW = CoreWebuiMessageConstants.KW_LOG_PASSED_MAX_CURR_WINDOW;

    public static final String KW_MSG_CANNOT_MAX_CURR_WINDOW = CoreWebuiMessageConstants.KW_MSG_CANNOT_MAX_CURR_WINDOW;

    public static final String KW_LOG_INFO_FINDING_WEB_ELEMENT_W_ID = CoreWebuiMessageConstants.KW_LOG_INFO_FINDING_WEB_ELEMENT_W_ID;

    public static final String KW_LOG_INFO_CANNOT_FIND_WEB_ELEMENT_BY_LOCATOR = CoreWebuiMessageConstants.KW_LOG_INFO_CANNOT_FIND_WEB_ELEMENT_BY_LOCATOR;

    public static final String KW_LOG_INFO_FINDING_WEB_ELEMENT_W_ID_SUCCESS = CoreWebuiMessageConstants.KW_LOG_INFO_FINDING_WEB_ELEMENT_W_ID_SUCCESS;

    public static final String KW_LOG_INFO_RETRIEVING_WEB_ELEMENT_FROM_CACHE = CoreWebuiMessageConstants.KW_LOG_INFO_RETRIEVING_WEB_ELEMENT_FROM_CACHE;

    public static final String KW_LOG_INFO_FINDING_WEB_ELEMENT_USING_HEURISTIC_METHOD = CoreWebuiMessageConstants.KW_LOG_INFO_FINDING_WEB_ELEMENT_USING_HEURISTIC_METHOD;

    public static final String KW_LOG_INFO_REPORT_FAILURE_WHEN_USING_HEURISTIC_METHOD = CoreWebuiMessageConstants.KW_LOG_INFO_REPORT_FAILURE_WHEN_USING_HEURISTIC_METHOD;

    public static final String KW_LOG_INFO_SUGGESTION_IN_SELECTING_ATTRIBUTES_FOR_LOCATOR = CoreWebuiMessageConstants.KW_LOG_INFO_SUGGESTION_IN_SELECTING_ATTRIBUTES_FOR_LOCATOR;

    public static final String KW_LOG_INFO_FOUND_WEB_ELEMENT_WITH_THIS_SMART_XPATH = CoreWebuiMessageConstants.KW_LOG_INFO_FOUND_WEB_ELEMENT_WITH_THIS_SMART_XPATH;

    public static final String KW_LOG_INFO_COULD_NOT_FIND_WEB_ELEMENT_WITH_THIS_SMART_XPATH = CoreWebuiMessageConstants.KW_LOG_INFO_COULD_NOT_FIND_WEB_ELEMENT_WITH_THIS_SMART_XPATH;

    public static final String KW_EXC_WEB_ELEMENT_W_ID_DOES_NOT_HAVE_SATISFY_PROP = CoreWebuiMessageConstants.KW_EXC_WEB_ELEMENT_W_ID_DOES_NOT_HAVE_SATISFY_PROP;

    public static final String KW_LOG_PASSED_WEB_ELEMT_W_ID_IS_NOT_PRESENT_AFTER = CoreWebuiMessageConstants.KW_LOG_PASSED_WEB_ELEMT_W_ID_IS_NOT_PRESENT_AFTER;

    public static final String KW_MSG_WEB_ELEMT_W_ID_IS_NOT_PRESENT_AFTER = CoreWebuiMessageConstants.KW_MSG_WEB_ELEMT_W_ID_IS_NOT_PRESENT_AFTER;

    public static final String KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_NOT_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_NOT_PRESENT;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_NOT_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_NOT_PRESENT;

    public static final String KW_LOG_PASSED_OBJ_X_IS_PRESENT = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_IS_PRESENT;

    public static final String KW_MSG_OBJ_IS_NOT_PRESENT_AFTER_X_SEC = CoreWebuiMessageConstants.KW_MSG_OBJ_IS_NOT_PRESENT_AFTER_X_SEC;

    public static final String KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_PRESENT;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_PRESENT;

    public static final String KW_LOG_PASSED_OBJ_X_IS_VISIBLE = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_IS_VISIBLE;

    public static final String KW_MSG_OBJ_IS_NOT_VISIBLE_AFTER_X_SEC = CoreWebuiMessageConstants.KW_MSG_OBJ_IS_NOT_VISIBLE_AFTER_X_SEC;

    public static final String KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_VISIBLE;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_VISIBLE;

    public static final String KW_LOG_PASSED_OBJ_X_IS_NOT_VISIBLE = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_IS_NOT_VISIBLE;

    public static final String KW_MSG_OBJ_IS_VISIBLE_AFTER_X_SEC = CoreWebuiMessageConstants.KW_MSG_OBJ_IS_VISIBLE_AFTER_X_SEC;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_TO_BE_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_TO_BE_VISIBLE;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_TO_BE_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_TO_BE_VISIBLE;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_TO_BE_NOT_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_TO_BE_NOT_VISIBLE;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_TO_BE_NOT_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_TO_BE_NOT_VISIBLE;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_NOT_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_NOT_VISIBLE;

    public static final String KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_NOT_VISIBLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_NOT_VISIBLE;

    public static final String KW_LOG_PASSED_OBJ_X_IS_CLICKABLE = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_IS_CLICKABLE;

    public static final String KW_MSG_OBJ_IS_NOT_CLICKABLE_AFTER_X_SEC = CoreWebuiMessageConstants.KW_MSG_OBJ_IS_NOT_CLICKABLE_AFTER_X_SEC;

    public static final String KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_CLICKABLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_CLICKABLE;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_CLICKABLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE_CLICKABLE;

    public static final String KW_LOG_PASSED_OBJ_X_IS_NOT_CLICKABLE = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_IS_NOT_CLICKABLE;

    public static final String KW_MSG_OBJ_IS_CLICKABLE_AFTER_X_SEC = CoreWebuiMessageConstants.KW_MSG_OBJ_IS_CLICKABLE_AFTER_X_SEC;

    public static final String KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_NOT_CLICKABLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_OBJ_TO_BE_NOT_CLICKABLE;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE__NOTCLICKABLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_TO_BE__NOTCLICKABLE;

    public static final String KW_MSG_VERIFY_OBJ_TO_BE_CLICKABLE = CoreWebuiMessageConstants.KW_MSG_VERIFY_OBJ_TO_BE_CLICKABLE;

    public static final String KW_MSG_VERIFY_OBJ_X_TO_BE_CLICKABLE = CoreWebuiMessageConstants.KW_MSG_VERIFY_OBJ_X_TO_BE_CLICKABLE;

    public static final String KW_MSG_VERIFY_OBJ_TO_BE_NOT_CLICKABLE = CoreWebuiMessageConstants.KW_MSG_VERIFY_OBJ_TO_BE_NOT_CLICKABLE;

    public static final String KW_MSG_VERIFY_OBJ_X_TO_BE_NOT_CLICKABLE = CoreWebuiMessageConstants.KW_MSG_VERIFY_OBJ_X_TO_BE_NOT_CLICKABLE;

    public static final String KW_LOG_INFO_CLICKING_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_CLICKING_ON_OBJ;

    public static final String KW_LOG_PASSED_OBJ_CLICKED = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_CLICKED;

    public static final String KW_MSG_CANNOT_CLICK_ON_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLICK_ON_OBJ_X;

    public static final String KW_MSG_CANNOT_CLICK_ON_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLICK_ON_OBJ;

    public static final String KW_LOG_INFO_SUBMITTING_ON_FORM_CONTAINING_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_SUBMITTING_ON_FORM_CONTAINING_OBJ;

    public static final String KW_LOG_PASSED_FORM_CONTAINING_OBJ_IS_SUBMITTED = CoreWebuiMessageConstants.KW_LOG_PASSED_FORM_CONTAINING_OBJ_IS_SUBMITTED;

    public static final String KW_MSG_CANNOT_SUBMIT_FORM_CONTAINING_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_SUBMIT_FORM_CONTAINING_OBJ_X;

    public static final String KW_MSG_CANNOT_SUBMIT_FORM_CONTAINING_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_SUBMIT_FORM_CONTAINING_OBJ;

    public static final String KW_LOG_INFO_DOUBLE_CLICK_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_DOUBLE_CLICK_ON_OBJ;

    public static final String KW_LOG_PASSED_OBJ_IS_DOUBLE_CLICKED_ON = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_IS_DOUBLE_CLICKED_ON;

    public static final String KW_MSG_CANNOT_DOUBLE_CLICK_ON_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_DOUBLE_CLICK_ON_OBJ_X;

    public static final String KW_MSG_CANNOT_DOUBLE_CLICK_ON_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_DOUBLE_CLICK_ON_OBJ;

    public static final String KW_LOG_INFO_RIGHT_CLICKING_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_RIGHT_CLICKING_ON_OBJ;

    public static final String KW_LOG_PASSED_OBJ_IS_RIGHT_CLICKED_ON = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_IS_RIGHT_CLICKED_ON;

    public static final String KW_MSG_CANNOT_RIGHT_CLICK_ON_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_RIGHT_CLICK_ON_OBJ_X;

    public static final String KW_MSG_CANNOT_RIGHT_CLICK_ON_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_RIGHT_CLICK_ON_OBJ;

    public static final String KW_LOG_INFO_MOVING_MOUSE_OVER_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_MOVING_MOUSE_OVER_OBJ;

    public static final String KW_LOG_PASSED_OBJ_IS_HOVERED = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_IS_HOVERED;

    public static final String KW_MSG_CANNOT_MOVE_MOUSE_OVER_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_MOVE_MOUSE_OVER_OBJ_X;

    public static final String KW_MSG_CANNOT_MOVE_MOUSE_OVER_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_MOVE_MOUSE_OVER_OBJ;

    public static final String KW_LOG_INFO_SENDING_KEYS_TO_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_SENDING_KEYS_TO_OBJ;

    public static final String KW_LOG_PASSED_KEYS_SENT_TO_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_KEYS_SENT_TO_OBJ;

    public static final String KW_MSG_CANNOT_SED_KEYS_TO_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_SED_KEYS_TO_OBJ_X;

    public static final String KW_MSG_CANNOT_SED_KEYS_TO_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_SED_KEYS_TO_OBJ;

    public static final String KW_LOG_INFO_UPLOADING_FILE_X_TO_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_INFO_UPLOADING_FILE_X_TO_OBJ_Y;

    public static final String KW_LOG_PASSED_FILE_X_SENT_TO_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_FILE_X_SENT_TO_OBJ_Y;

    public static final String KW_MSG_CANNOT_UPLOAD_FILE_X_TO_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_UPLOAD_FILE_X_TO_OBJ_Y;

    public static final String KW_MSG_CANNOT_UPLOAD_FILE_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_UPLOAD_FILE_X;

    public static final String KW_LOG_INFO_FOCUSING_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_FOCUSING_ON_OBJ;

    public static final String KW_LOG_PASSED_OBJ_IS_FOCUSED = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_IS_FOCUSED;

    public static final String KW_MSG_CANNOT_FOCUS_ON_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_FOCUS_ON_OBJ_X;

    public static final String KW_MSG_CANNOT_FOCUS_ON_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_FOCUS_ON_OBJ;

    public static final String KW_LOG_INFO_GETTING_OBJ_TXT = CoreWebuiMessageConstants.KW_LOG_INFO_GETTING_OBJ_TXT;

    public static final String KW_LOG_PASSED_OBJ_TXT_IS = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_TXT_IS;

    public static final String KW_MSG_CANNOT_GET_TXT_OF_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_TXT_OF_OBJ_X;

    public static final String KW_MSG_CANNOT_GET_OBJ_TXT = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_OBJ_TXT;

    public static final String KW_LOG_INFO_CHECKING_ATTR = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_ATTR;

    public static final String KW_EXC_ATTR_IS_NULL = CoreWebuiMessageConstants.KW_EXC_ATTR_IS_NULL;

    public static final String KW_LOG_INFO_GETTING_OBJ_ATTR = CoreWebuiMessageConstants.KW_LOG_INFO_GETTING_OBJ_ATTR;

    public static final String KW_LOG_PASSED_OBJ_ATTR_IS = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_ATTR_IS;

    public static final String KW_MSG_CANNOT_GET_ATTR_X_OF_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_ATTR_X_OF_OBJ_Y;

    public static final String KW_MSG_CANNOT_GET_OBJ_ATTR = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_OBJ_ATTR;

    public static final String KW_LOG_INFO_CHECKING_TXT = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_TXT;

    public static final String KW_EXC_TXT_IS_NULL = CoreWebuiMessageConstants.KW_EXC_TXT_IS_NULL;

    public static final String KW_LOG_INFO_CLEARING_OBJ_TXT = CoreWebuiMessageConstants.KW_LOG_INFO_CLEARING_OBJ_TXT;

    public static final String KW_LOG_INFO_SETTING_OBJ_TXT_TO_VAL = CoreWebuiMessageConstants.KW_LOG_INFO_SETTING_OBJ_TXT_TO_VAL;

    public static final String KW_LOG_INFO_SETTING_OBJ_TXT_TO_ENCRYPTED_VAL = CoreWebuiMessageConstants.KW_LOG_INFO_SETTING_OBJ_TXT_TO_ENCRYPTED_VAL;

    public static final String KW_LOG_PASSED_TXT_IS_SET_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_TXT_IS_SET_ON_OBJ;

    public static final String KW_LOG_PASSED_ENCRYPTED_TXT_IS_SET_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_ENCRYPTED_TXT_IS_SET_ON_OBJ;

    public static final String KW_MSG_CANNOT_SET_TXT_X_OF_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_SET_TXT_X_OF_OBJ_Y;

    public static final String KW_MSG_CANNOT_SET_ENCRYPTED_TEXT_FOR_OBJECT = CoreWebuiMessageConstants.KW_MSG_CANNOT_SET_ENCRYPTED_TEXT_FOR_OBJECT;

    public static final String KW_MSG_CANNOT_SET_TXT = CoreWebuiMessageConstants.KW_MSG_CANNOT_SET_TXT;

    public static final String KW_LOG_INFO_CHECKING_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_ON_OBJ;

    public static final String KW_LOG_PASSED_OBJ_IS_CHECKED = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_IS_CHECKED;

    public static final String KW_MSG_CANNOT_CHECK_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_CHECK_OBJ_X;

    public static final String KW_MSG_CANNOT_CHECK_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_CHECK_OBJ;

    public static final String KW_LOG_INFO_UNCHECKING_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_UNCHECKING_ON_OBJ;

    public static final String KW_LOG_PASSED_OBJ_IS_UNCHECKED = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_IS_UNCHECKED;

    public static final String KW_MSG_CANNOT_UNCHECK_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_UNCHECK_OBJ_X;

    public static final String KW_MSG_CANNOT_UNCHECK_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_UNCHECK_OBJ;

    public static final String KW_LOG_INFO_CHECKING_INDEX_RANGE = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_INDEX_RANGE;

    public static final String KW_EXC_INDEX_RANGE_IS_NULL = CoreWebuiMessageConstants.KW_EXC_INDEX_RANGE_IS_NULL;

    public static final String KW_EXC_INDEX_RANGE_CANNOT_BE_NULL = CoreWebuiMessageConstants.KW_EXC_INDEX_RANGE_CANNOT_BE_NULL;

    public static final String KW_LOG_INFO_SELECTING_OBJ_OPTS_W_INDEX_IN = CoreWebuiMessageConstants.KW_LOG_INFO_SELECTING_OBJ_OPTS_W_INDEX_IN;

    public static final String KW_LOG_INFO_OPT_W_INDEX_X_IS_SELECTED = CoreWebuiMessageConstants.KW_LOG_INFO_OPT_W_INDEX_X_IS_SELECTED;

    public static final String KW_LOG_PASSED_OPTS_W_INDEX_IN_X_ARE_SELECTED_ON_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_OPTS_W_INDEX_IN_X_ARE_SELECTED_ON_OBJ_Y;

    public static final String KW_MSG_CANNOT_SEL_OPT_BY_INDEX_X_OF_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_SEL_OPT_BY_INDEX_X_OF_OBJ_Y;

    public static final String KW_MSG_CANNOT_SEL_OPT_BY_INDEX = CoreWebuiMessageConstants.KW_MSG_CANNOT_SEL_OPT_BY_INDEX;

    public static final String KW_LOG_INFO_CHECKING_VAL_PARAM = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_VAL_PARAM;

    public static final String KW_EXC_VAL_IS_NULL = CoreWebuiMessageConstants.KW_EXC_VAL_IS_NULL;

    public static final String KW_LOG_INFO_SELECTING_OPTS_ON_OBJ_X_W_VAL_Y = CoreWebuiMessageConstants.KW_LOG_INFO_SELECTING_OPTS_ON_OBJ_X_W_VAL_Y;

    public static final String KW_LOG_INFO_SELECTED_OPT_AT_INDEX_W_VAL = CoreWebuiMessageConstants.KW_LOG_INFO_SELECTED_OPT_AT_INDEX_W_VAL;

    public static final String KW_MSG_CANNOT_SELECT_OPT_BY_VAL_OF_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_SELECT_OPT_BY_VAL_OF_OBJ;

    public static final String KW_MSG_CANNOT_SEL_OPT_BY_VAL = CoreWebuiMessageConstants.KW_MSG_CANNOT_SEL_OPT_BY_VAL;

    public static final String KW_LOG_INFO_SELECTING_ALL_OPT_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_SELECTING_ALL_OPT_ON_OBJ;

    public static final String KW_LOG_PASSED_ALL_OBJ_OPTS_ARE_SELECTED = CoreWebuiMessageConstants.KW_LOG_PASSED_ALL_OBJ_OPTS_ARE_SELECTED;

    public static final String KW_MSG_CANNOT_SELECT_ALL_OBJ_OPTS = CoreWebuiMessageConstants.KW_MSG_CANNOT_SELECT_ALL_OBJ_OPTS;

    public static final String KW_MSG_CANNOT_SELECT_ALL_OPTS = CoreWebuiMessageConstants.KW_MSG_CANNOT_SELECT_ALL_OPTS;

    public static final String KW_LOG_INFO_CHECKING_LBL_PARAM = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_LBL_PARAM;

    public static final String KW_EXC_LBL_IS_NULL = CoreWebuiMessageConstants.KW_EXC_LBL_IS_NULL;

    public static final String KW_LOG_INFO_SELECTING_OPTS_ON_OBJ_X_W_LBL_Y = CoreWebuiMessageConstants.KW_LOG_INFO_SELECTING_OPTS_ON_OBJ_X_W_LBL_Y;

    public static final String KW_LOG_INFO_OPT_AT_IDX_X_W_LBL_TXT_Y_IS_SELECTED = CoreWebuiMessageConstants.KW_LOG_INFO_OPT_AT_IDX_X_W_LBL_TXT_Y_IS_SELECTED;

    public static final String KW_MSG_CANNOT_SEL_OPT_BY_LBL_OF_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_SEL_OPT_BY_LBL_OF_OBJ;

    public static final String KW_MSG_CANNOT_SEL_OPT_BY_LBL = CoreWebuiMessageConstants.KW_MSG_CANNOT_SEL_OPT_BY_LBL;

    public static final String KW_LOG_INFO_DESELECTING_OPTS_ON_OBJ_W_IDX = CoreWebuiMessageConstants.KW_LOG_INFO_DESELECTING_OPTS_ON_OBJ_W_IDX;

    public static final String KW_LOG_INFO_DESELECTED_OPT_IDX_X = CoreWebuiMessageConstants.KW_LOG_INFO_DESELECTED_OPT_IDX_X;

    public static final String KW_LOG_PASSED_OPTS_W_IDX_IN_X_ARE_DESELECTED_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_OPTS_W_IDX_IN_X_ARE_DESELECTED_ON_OBJ;

    public static final String KW_MSG_CANNOT_DESELECT_OPT_BY_IDX_OF_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_DESELECT_OPT_BY_IDX_OF_OBJ;

    public static final String KW_MSG_CANNOT_DESELECT_OPT_BY_IDX = CoreWebuiMessageConstants.KW_MSG_CANNOT_DESELECT_OPT_BY_IDX;

    public static final String KW_LOG_INFO_DESELECTING_OPTS_ON_OBJ_W_VAL = CoreWebuiMessageConstants.KW_LOG_INFO_DESELECTING_OPTS_ON_OBJ_W_VAL;

    public static final String KW_LOG_INFO_OPT_AT_IDX_X_W_VAL_Y_IS_SELECTED = CoreWebuiMessageConstants.KW_LOG_INFO_OPT_AT_IDX_X_W_VAL_Y_IS_SELECTED;

    public static final String KW_LOG_PASSED_OPTS_W_VAL_ARE_DESELECTED_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_OPTS_W_VAL_ARE_DESELECTED_ON_OBJ;

    public static final String KW_MSG_CANNOT_DESELECT_OPT_BY_VAL_OF_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_DESELECT_OPT_BY_VAL_OF_OBJ;

    public static final String KW_MSG_CANNOT_DESELECT_OPT_BY_VAL = CoreWebuiMessageConstants.KW_MSG_CANNOT_DESELECT_OPT_BY_VAL;

    public static final String KW_LOG_INFO_DESELECTING_OPTS_ON_OBJ_X_W_LBL_Y = CoreWebuiMessageConstants.KW_LOG_INFO_DESELECTING_OPTS_ON_OBJ_X_W_LBL_Y;

    public static final String KW_LOG_INFO_OPT_AT_IDX_X_W_LBL_TXT_Y_IS_DESELECTED = CoreWebuiMessageConstants.KW_LOG_INFO_OPT_AT_IDX_X_W_LBL_TXT_Y_IS_DESELECTED;

    public static final String KW_LOG_PASSED_DESELECTED_OPTS_W_LBL_X_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_DESELECTED_OPTS_W_LBL_X_ON_OBJ;

    public static final String KW_MSG_CANNOT_DESEL_OPT_BY_LBL_OF_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_DESEL_OPT_BY_LBL_OF_OBJ;

    public static final String KW_MSG_CANNOT_DESEL_OPT_BY_LBL = CoreWebuiMessageConstants.KW_MSG_CANNOT_DESEL_OPT_BY_LBL;

    public static final String KW_LOG_INFO_DESELECTING_ALL_OPTS_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_DESELECTING_ALL_OPTS_ON_OBJ;

    public static final String KW_LOG_PASSED_DESELECTED_ALL_OPTS_ON_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_DESELECTED_ALL_OPTS_ON_OBJ;

    public static final String KW_MSG_CANNOT_SEL_ALL_OPTS_ON_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_SEL_ALL_OPTS_ON_OBJ;

    public static final String KW_MSG_CANNOT_SEL_ALL_OPTS = CoreWebuiMessageConstants.KW_MSG_CANNOT_SEL_ALL_OPTS;

    public static final String KW_MSG_OBJ_X_IS_NOT_CHECKED = CoreWebuiMessageConstants.KW_MSG_OBJ_X_IS_NOT_CHECKED;

    public static final String KW_LOG_PASSED_OBJ_X_IS_CHECKED = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_IS_CHECKED;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_IS_CHECKED = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_IS_CHECKED;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_IS_CHECKED = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_IS_CHECKED;

    public static final String KW_MSG_OBJ_X_IS_CHECKED = CoreWebuiMessageConstants.KW_MSG_OBJ_X_IS_CHECKED;

    public static final String KW_LOG_PASSED_OBJ_X_IS_NOT_CHECKED = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_IS_NOT_CHECKED;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_IS_NOT_CHECKED = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_IS_NOT_CHECKED;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_IS_NOT_CHECKED = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_IS_NOT_CHECKED;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_IS_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_IS_PRESENT;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_IS_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_IS_PRESENT;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_IS_NOT_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_IS_NOT_PRESENT;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_IS_NOT_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_IS_NOT_PRESENT;

    public static final String KW_LOG_INFO_ACCEPTING_ALERT = CoreWebuiMessageConstants.KW_LOG_INFO_ACCEPTING_ALERT;

    public static final String KW_LOG_PASSED_ALERT_ACCEPTED = CoreWebuiMessageConstants.KW_LOG_PASSED_ALERT_ACCEPTED;

    public static final String KW_MSG_NO_ALERT_FOUND = CoreWebuiMessageConstants.KW_MSG_NO_ALERT_FOUND;

    public static final String KW_MSG_CANNOT_ACCEPT_ALERT = CoreWebuiMessageConstants.KW_MSG_CANNOT_ACCEPT_ALERT;

    public static final String KW_LOG_INFO_DISMISSING_ALERT = CoreWebuiMessageConstants.KW_LOG_INFO_DISMISSING_ALERT;

    public static final String KW_LOG_PASSED_ALERT_DISMISSED = CoreWebuiMessageConstants.KW_LOG_PASSED_ALERT_DISMISSED;

    public static final String KW_MSG_CANNOT_DISMISS_ALERT = CoreWebuiMessageConstants.KW_MSG_CANNOT_DISMISS_ALERT;

    public static final String KW_LOG_INFO_GETTING_ALERT_TXT = CoreWebuiMessageConstants.KW_LOG_INFO_GETTING_ALERT_TXT;

    public static final String KW_LOG_PASSED_GET_ALERT_TXT_SUCCESSFULLY = CoreWebuiMessageConstants.KW_LOG_PASSED_GET_ALERT_TXT_SUCCESSFULLY;

    public static final String KW_MSG_CANNOT_GET_ALERT_TXT = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_ALERT_TXT;

    public static final String KW_LOG_INFO_SETTING_ALERT_TXT = CoreWebuiMessageConstants.KW_LOG_INFO_SETTING_ALERT_TXT;

    public static final String KW_LOG_PASSED_SET_ALERT_TXT_SUCCESSFULLY = CoreWebuiMessageConstants.KW_LOG_PASSED_SET_ALERT_TXT_SUCCESSFULLY;

    public static final String KW_MSG_CANNOT_SET_ALERT_TXT = CoreWebuiMessageConstants.KW_MSG_CANNOT_SET_ALERT_TXT;

    public static final String KW_LOG_PASSED_ALERT_IS_PRESENT_AFTER_X_SEC = CoreWebuiMessageConstants.KW_LOG_PASSED_ALERT_IS_PRESENT_AFTER_X_SEC;

    public static final String KW_MSG_NO_ALERT_FOUND_AFTER_X_SEC = CoreWebuiMessageConstants.KW_MSG_NO_ALERT_FOUND_AFTER_X_SEC;

    public static final String KW_MSG_CANNOT_WAIT_FOR_ALERT = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_ALERT;

    public static final String KW_MSG_CANNOT_VERIFY_ALERT_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_ALERT_PRESENT;

    public static final String KW_MSG_CANNOT_VERIFY_ALERT_NOT_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_ALERT_NOT_PRESENT;

    public static final String KW_LOG_PASSED_TXT_X_IS_PRESENT_ON_PAGE_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_TXT_X_IS_PRESENT_ON_PAGE_Y;

    public static final String KW_MSG_TXT_X_IS_NOT_PRESENT_ON_PAGE_Y = CoreWebuiMessageConstants.KW_MSG_TXT_X_IS_NOT_PRESENT_ON_PAGE_Y;

    public static final String KW_MSG_CANNOT_VERIFY_TXT_X_IS_PRESENT_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_TXT_X_IS_PRESENT_Y;

    public static final String KW_MSG_CANNOT_VERIFY_TXT_IS_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_TXT_IS_PRESENT;

    public static final String KW_MSG_TXT_X_IS_PRESENT_ON_PAGE_Y = CoreWebuiMessageConstants.KW_MSG_TXT_X_IS_PRESENT_ON_PAGE_Y;

    public static final String KW_MSG_CANNOT_VERIFY_TXT_IS_NOT_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_TXT_IS_NOT_PRESENT;

    public static final String KW_LOG_PASSED_TXT_X_IS_NOT_PRESENT_ON_PAGE = CoreWebuiMessageConstants.KW_LOG_PASSED_TXT_X_IS_NOT_PRESENT_ON_PAGE;

    public static final String KW_MSG_CANNOT_VERIFY_TXT_IS_NOT_PRESENT_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_TXT_IS_NOT_PRESENT_Y;

    public static final String KW_LOG_INFO_CHECKING_TITLE = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_TITLE;

    public static final String KW_EXC_TITLE_IS_NULL = CoreWebuiMessageConstants.KW_EXC_TITLE_IS_NULL;

    public static final String KW_LOG_INFO_SWITCHING_TO_WINDOW_W_TITLE_X = CoreWebuiMessageConstants.KW_LOG_INFO_SWITCHING_TO_WINDOW_W_TITLE_X;

    public static final String KW_LOG_PASSED_SWITCHED_TO_WINDOW_W_TITLE_X = CoreWebuiMessageConstants.KW_LOG_PASSED_SWITCHED_TO_WINDOW_W_TITLE_X;

    public static final String KW_MSG_CANNOT_FIND_WINDOW_W_TITLE_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_FIND_WINDOW_W_TITLE_X;

    public static final String KW_MSG_CANNOT_SWITCH_TO_WINDOW_TITLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_SWITCH_TO_WINDOW_TITLE;

    public static final String KW_MSG_CANNOT_SWITCH_TO_WINDOW_W_TITLE_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_SWITCH_TO_WINDOW_W_TITLE_X;

    public static final String KW_LOG_INFO_CLOSING_WINDOW_W_TITLE_X = CoreWebuiMessageConstants.KW_LOG_INFO_CLOSING_WINDOW_W_TITLE_X;

    public static final String KW_LOG_PASSED_CLOSED_WINDOW_W_TITLE_X = CoreWebuiMessageConstants.KW_LOG_PASSED_CLOSED_WINDOW_W_TITLE_X;

    public static final String KW_MSG_CANNOT_CLOSE_WINDOW_TITLE = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLOSE_WINDOW_TITLE;

    public static final String KW_MSG_CANNOT_CLOSE_WINDOW_W_TITLE_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLOSE_WINDOW_W_TITLE_X;

    public static final String KW_LOG_INFO_SWITCHING_TO_WINDOW_W_URL_X = CoreWebuiMessageConstants.KW_LOG_INFO_SWITCHING_TO_WINDOW_W_URL_X;

    public static final String KW_LOG_PASSED_SWITCHED_TO_WINDOW_W_URL_X = CoreWebuiMessageConstants.KW_LOG_PASSED_SWITCHED_TO_WINDOW_W_URL_X;

    public static final String KW_MSG_CANNOT_FIND_WINDOW_W_URL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_FIND_WINDOW_W_URL_X;

    public static final String KW_MSG_CANNOT_SWITCH_TO_WINDOW_URL = CoreWebuiMessageConstants.KW_MSG_CANNOT_SWITCH_TO_WINDOW_URL;

    public static final String KW_MSG_CANNOT_SWITCH_TO_WINDOW_W_URL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_SWITCH_TO_WINDOW_W_URL_X;

    public static final String KW_LOG_INFO_CLOSING_WINDOW_W_URL_X = CoreWebuiMessageConstants.KW_LOG_INFO_CLOSING_WINDOW_W_URL_X;

    public static final String KW_LOG_PASSED_CLOSED_WINDOW_W_URL_X = CoreWebuiMessageConstants.KW_LOG_PASSED_CLOSED_WINDOW_W_URL_X;

    public static final String KW_MSG_CANNOT_CLOSE_WINDOW_URL = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLOSE_WINDOW_URL;

    public static final String KW_MSG_CANNOT_CLOSE_WINDOW_W_URL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLOSE_WINDOW_W_URL_X;

    public static final String KW_LOG_INFO_CHECKING_INDEX = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_INDEX;

    public static final String KW_EXC_INDEX_IS_NULL = CoreWebuiMessageConstants.KW_EXC_INDEX_IS_NULL;

    public static final String KW_LOG_INFO_WITCHING_WINDOW_W_IDX_X = CoreWebuiMessageConstants.KW_LOG_INFO_WITCHING_WINDOW_W_IDX_X;

    public static final String KW_LOG_PASSED_SWITCHED_WINDOW_W_IDX_X = CoreWebuiMessageConstants.KW_LOG_PASSED_SWITCHED_WINDOW_W_IDX_X;

    public static final String KW_MSG_CANNOT_FIND_WINDOW_W_IDX_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_FIND_WINDOW_W_IDX_X;

    public static final String KW_MSG_CANNOT_SWITCH_TO_WINDOW_IDX = CoreWebuiMessageConstants.KW_MSG_CANNOT_SWITCH_TO_WINDOW_IDX;

    public static final String KW_MSG_CANNOT_SWITCH_TO_WINDOW_W_IDX_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_SWITCH_TO_WINDOW_W_IDX_X;

    public static final String KW_LOG_INFO_CLOSING_WINDOW_W_IDX_X = CoreWebuiMessageConstants.KW_LOG_INFO_CLOSING_WINDOW_W_IDX_X;

    public static final String KW_LOG_PASSED_CLOSED_WINDOW_W_IDX_X = CoreWebuiMessageConstants.KW_LOG_PASSED_CLOSED_WINDOW_W_IDX_X;

    public static final String KW_MSG_CANNOT_CLOSE_WINDOW_IDX = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLOSE_WINDOW_IDX;

    public static final String KW_MSG_CANNOT_CLOSE_WINDOW_W_IDX_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLOSE_WINDOW_W_IDX_X;

    public static final String KW_LOG_INFO_COUNTING_TOTAL_OPTS_OF_OBJ_X = CoreWebuiMessageConstants.KW_LOG_INFO_COUNTING_TOTAL_OPTS_OF_OBJ_X;

    public static final String KW_LOG_PASSED_X_OPTS_OF_OBJ_Y_COUNTED = CoreWebuiMessageConstants.KW_LOG_PASSED_X_OPTS_OF_OBJ_Y_COUNTED;

    public static final String KW_MSG_CANNOT_GET_TOTAL_OPTS_OF_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_TOTAL_OPTS_OF_OBJ_X;

    public static final String KW_MSG_CANNOT_GET_TOTAL_OPTS_OF_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_TOTAL_OPTS_OF_OBJ;

    public static final String KW_LOG_INFO_COUNTING_TOTAL_SELECTED_OPTS_OF_OBJ_X = CoreWebuiMessageConstants.KW_LOG_INFO_COUNTING_TOTAL_SELECTED_OPTS_OF_OBJ_X;

    public static final String KW_LOG_PASSED_X_SELECTED_OPTS_OF_OBJ_X_COUNTED = CoreWebuiMessageConstants.KW_LOG_PASSED_X_SELECTED_OPTS_OF_OBJ_X_COUNTED;

    public static final String KW_MSG_CANNOT_GET_NO_OF_SELECTED_OPTS_OF_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_NO_OF_SELECTED_OPTS_OF_OBJ_X;

    public static final String KW_MSG_CANNOT_GET_NO_OF_SELECTED_OPTS_OF_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_NO_OF_SELECTED_OPTS_OF_OBJ;

    public static final String KW_LOG_INFO_CHECKING_LBL = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_LBL;

    public static final String KW_EXC_LBL_CANNOT_BE_NULL = CoreWebuiMessageConstants.KW_EXC_LBL_CANNOT_BE_NULL;

    public static final String KW_MSG_THERE_IS_NO_OPT_W_LBL_X_PRESENT_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_THERE_IS_NO_OPT_W_LBL_X_PRESENT_IN_OBJ_Y;

    public static final String KW_LOG_PASSED_X_OPTS_W_LBL_Y_PRESENTED_IN_OBJ_Z = CoreWebuiMessageConstants.KW_LOG_PASSED_X_OPTS_W_LBL_Y_PRESENTED_IN_OBJ_Z;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_LBL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_LBL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_LBL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_LBL_X;

    public static final String KW_LOG_INFO_CHECKING_VAL = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_VAL;

    public static final String KW_EXC_VAL_CANNOT_BE_NULL = CoreWebuiMessageConstants.KW_EXC_VAL_CANNOT_BE_NULL;

    public static final String KW_MSG_THERE_IS_NO_OPT_W_VAL_X_PRESENT_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_THERE_IS_NO_OPT_W_VAL_X_PRESENT_IN_OBJ_Y;

    public static final String KW_LOG_PASSED_X_OPTS_W_VAL_Y_PRESENTED_IN_OBJ_Z = CoreWebuiMessageConstants.KW_LOG_PASSED_X_OPTS_W_VAL_Y_PRESENTED_IN_OBJ_Z;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_VAL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_VAL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_VAL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_PRESENT_BY_VAL_X;

    public static final String KW_LOG_PASSED_THERE_IS_NO_OPT_W_LBL_X_PRESENT_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_THERE_IS_NO_OPT_W_LBL_X_PRESENT_IN_OBJ_Y;

    public static final String KW_MSG_X_OPTS_W_LBL_Y_PRESENTED_IN_OBJ_Z = CoreWebuiMessageConstants.KW_MSG_X_OPTS_W_LBL_Y_PRESENTED_IN_OBJ_Z;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_LBL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_LBL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_LBL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_LBL_X;

    public static final String KW_LOG_PASSED_THERE_IS_NO_OPT_W_VAL_X_PRESENT_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_THERE_IS_NO_OPT_W_VAL_X_PRESENT_IN_OBJ_Y;

    public static final String KW_MSG_X_OPTS_W_VAL_Y_PRESENTED_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_X_OPTS_W_VAL_Y_PRESENTED_IN_OBJ;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_VAL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_VAL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_VAL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_PRESENT_BY_VAL_X;

    public static final String KW_MSG_ONLY_X_IN_Y_OPTS_W_LBL_Z_SELECTED_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_ONLY_X_IN_Y_OPTS_W_LBL_Z_SELECTED_IN_OBJ;

    public static final String KW_LOG_PASSED_SELECTED_ALL_OPT_W_LBL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_SELECTED_ALL_OPT_W_LBL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_LBL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_LBL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_LBL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_LBL_X;

    public static final String KW_MSG_ONLY_X_IN_Y_OPTS_W_VAL_Z_SELECTED_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_ONLY_X_IN_Y_OPTS_W_VAL_Z_SELECTED_IN_OBJ;

    public static final String KW_LOG_PASSED_SELECTED_ALL_OPT_W_VAL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_SELECTED_ALL_OPT_W_VAL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_VAL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_VAL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_VAL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_BY_VAL_X;

    public static final String KW_MSG_ONLY_X_IN_Y_OPTS_W_LBL_Z_UNSELECTED_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_ONLY_X_IN_Y_OPTS_W_LBL_Z_UNSELECTED_IN_OBJ;

    public static final String KW_LOG_PASSED_UNSELECTED_ALL_OPT_W_LBL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_UNSELECTED_ALL_OPT_W_LBL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_LBL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_LBL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_LBL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_LBL_X;

    public static final String KW_MSG_ONLY_X_IN_Y_OPTS_W_VAL_Z_UNSELECTED_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_ONLY_X_IN_Y_OPTS_W_VAL_Z_UNSELECTED_IN_OBJ;

    public static final String KW_LOG_PASSED_UNSELECTED_ALL_OPT_W_VAL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_UNSELECTED_ALL_OPT_W_VAL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_VAL_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_VAL_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_VAL_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_UNSELECTED_BY_VAL_X;

    public static final String KW_MSG_ONLY_X_IN_Y_OPTS_W_IDX_RANGE_Z_SELECTED_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_ONLY_X_IN_Y_OPTS_W_IDX_RANGE_Z_SELECTED_IN_OBJ;

    public static final String KW_LOG_PASSED_SELECTED_ALL_OPT_W_IDX_RANGE_IN_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_SELECTED_ALL_OPT_W_IDX_RANGE_IN_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_IN_IDX_RANGE_X_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_IN_IDX_RANGE_X_IN_OBJ;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_IN_IDX_RANGE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_SELECTED_IN_IDX_RANGE;

    public static final String KW_MSG_ONLY_X_IN_Y_OPTS_W_IDX_RANGE_Z_UNSELECTED_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_ONLY_X_IN_Y_OPTS_W_IDX_RANGE_Z_UNSELECTED_IN_OBJ;

    public static final String KW_LOG_PASSED_UNSELECTED_ALL_OPT_W_IDX_RANGE_IN_X_IN_OBJ_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_UNSELECTED_ALL_OPT_W_IDX_RANGE_IN_X_IN_OBJ_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_SELECTED_IN_IDX_RANGE_X_IN_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_SELECTED_IN_IDX_RANGE_X_IN_OBJ;

    public static final String KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_SELECTED_IN_IDX_RANGE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OPT_IS_NOT_SELECTED_IN_IDX_RANGE;

    public static final String KW_LOG_WARNING_SWITCHING_TO_DEFAULT_CONTENT_FAILED_BC_ALERT_ON_PAGE = CoreWebuiMessageConstants.KW_LOG_WARNING_SWITCHING_TO_DEFAULT_CONTENT_FAILED_BC_ALERT_ON_PAGE;

    public static final String KW_LOG_INFO_SWITCHING_TO_DEFAULT_CONTENT = CoreWebuiMessageConstants.KW_LOG_INFO_SWITCHING_TO_DEFAULT_CONTENT;

    public static final String KW_LOG_WARNING_SWITCHING_TO_DEFAULT_CONTENT_FAILED_BC_OF_X = CoreWebuiMessageConstants.KW_LOG_WARNING_SWITCHING_TO_DEFAULT_CONTENT_FAILED_BC_OF_X;

    public static final String KW_LOG_PASSED_SWITCHED_TO_DEFAULT_CONTENT_SUCCESSFULLY = CoreWebuiMessageConstants.KW_LOG_PASSED_SWITCHED_TO_DEFAULT_CONTENT_SUCCESSFULLY;

    public static final String KW_MSG_CANNOT_SWITCH_TO_DEFAULT_CONTENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_SWITCH_TO_DEFAULT_CONTENT;

    public static final String KW_LOG_WARNING_CANNOT_DEL_COOKIES_BC_BROWSER_CLOSED = CoreWebuiMessageConstants.KW_LOG_WARNING_CANNOT_DEL_COOKIES_BC_BROWSER_CLOSED;

    public static final String KW_MSG_CANNOT_DEL_ALL_COOKIES = CoreWebuiMessageConstants.KW_MSG_CANNOT_DEL_ALL_COOKIES;

    public static final String KW_LOG_PASSED_DEL_ALL_COOKIE = CoreWebuiMessageConstants.KW_LOG_PASSED_DEL_ALL_COOKIE;

    public static final String KW_MSG_PASSED_WAIT_FOR_PAGE_LOAD = CoreWebuiMessageConstants.KW_MSG_PASSED_WAIT_FOR_PAGE_LOAD;

    public static final String KW_MSG_CANNOT_WAIT_FOR_PAGE_LOAD = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_PAGE_LOAD;

    public static final String KW_LOF_INFO_CHK_TO = CoreWebuiMessageConstants.KW_LOF_INFO_CHK_TO;

    public static final String KW_EXC_TO_IS_NULL = CoreWebuiMessageConstants.KW_EXC_TO_IS_NULL;

    public static final String KW_LOG_INFO_CHK_PROP_NAME = CoreWebuiMessageConstants.KW_LOG_INFO_CHK_PROP_NAME;

    public static final String KW_EXC_PROP_NAME_IS_NULL = CoreWebuiMessageConstants.KW_EXC_PROP_NAME_IS_NULL;

    public static final String KW_LOG_INFO_NOT_FOUND_PROP_CREATING_NEW_PROP = CoreWebuiMessageConstants.KW_LOG_INFO_NOT_FOUND_PROP_CREATING_NEW_PROP;

    public static final String KW_LOG_INFO_NOT_FOUND_PROP_DO_NOTHING = CoreWebuiMessageConstants.KW_LOG_INFO_NOT_FOUND_PROP_DO_NOTHING;

    public static final String KW_LOG_INFO_CHK_MODIFY_VAL = CoreWebuiMessageConstants.KW_LOG_INFO_CHK_MODIFY_VAL;

    public static final String KW_LOG_INFO_MODIFY_VAL_NULL_SO_NOT_MODIFYING_VAL = CoreWebuiMessageConstants.KW_LOG_INFO_MODIFY_VAL_NULL_SO_NOT_MODIFYING_VAL;

    public static final String KW_LOG_INFO_CHK_MATCH_COND = CoreWebuiMessageConstants.KW_LOG_INFO_CHK_MATCH_COND;

    public static final String KW_LOG_INFO_MATCH_COND_NULL_SO_NOT_MODIFYING_MATCH_COND = CoreWebuiMessageConstants.KW_LOG_INFO_MATCH_COND_NULL_SO_NOT_MODIFYING_MATCH_COND;

    public static final String KW_LOG_INFO_INVALID_MATCH_COND = CoreWebuiMessageConstants.KW_LOG_INFO_INVALID_MATCH_COND;

    public static final String KW_MSG_MODIFY_OBJ_PROP_SUCESSFULLY = CoreWebuiMessageConstants.KW_MSG_MODIFY_OBJ_PROP_SUCESSFULLY;

    public static final String KW_MSG_CANNOT_MODIFY_OBJ_PROP = CoreWebuiMessageConstants.KW_MSG_CANNOT_MODIFY_OBJ_PROP;

    public static final String KW_MSG_REMOVE_OBJ_PROP_X_OF_OBJ_Y = CoreWebuiMessageConstants.KW_MSG_REMOVE_OBJ_PROP_X_OF_OBJ_Y;

    public static final String KW_MSG_REMOVE_OBJ_PROP_SUCESSFULLY = CoreWebuiMessageConstants.KW_MSG_REMOVE_OBJ_PROP_SUCESSFULLY;

    public static final String KW_MSG_CANNOT_REMOVE_OBJ_PROP = CoreWebuiMessageConstants.KW_MSG_CANNOT_REMOVE_OBJ_PROP;

    public static final String KW_LOG_INFO_CHK_SRC_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_CHK_SRC_OBJ;

    public static final String KW_EXC_SRC_OBJ_IS_NULL = CoreWebuiMessageConstants.KW_EXC_SRC_OBJ_IS_NULL;

    public static final String KW_LOG_INFO_CHK_DEST_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_CHK_DEST_OBJ;

    public static final String KW_EXC_DEST_OBJ_IS_NULL = CoreWebuiMessageConstants.KW_EXC_DEST_OBJ_IS_NULL;

    public static final String KW_LOG_INFO_START_DRAGGING_OBJ_W_ID_X_TO_OBJ_W_ID_Y = CoreWebuiMessageConstants.KW_LOG_INFO_START_DRAGGING_OBJ_W_ID_X_TO_OBJ_W_ID_Y;

    public static final String KW_LOG_PASSED_DRAGGED_OBJ_W_ID_X_TO_OBJ_W_ID_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_DRAGGED_OBJ_W_ID_X_TO_OBJ_W_ID_Y;

    public static final String KW_MSG_CANNOT_DRAG_AND_DROP_TO_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_DRAG_AND_DROP_TO_OBJ;

    public static final String KW_LOG_INFO_START_DRAGGING_OBJ_BY_OFFSET_DISTANCE_X_Y = "Start dragging object with id ''{0}'' by offset distance x = {1} and y = {2}";

    public static final String KW_LOG_PASSED_DRAGGED_OBJ_BY_OFFSET_DISTANCE_X_Y = "Dragged object with id ''{0}'' by offset distance x = {1} and y = {2} successfully";

    public static final String KW_MSG_CANNOT_DRAG_AND_DROP_BY_OFFSET_DISTANCE = CoreWebuiMessageConstants.KW_MSG_CANNOT_DRAG_AND_DROP_BY_OFFSET_DISTANCE;

    public static final String KW_LOG_INFO_CHECKING_USERNAME = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_USERNAME;

    public static final String KW_EXC_USERNAME_IS_NULL = CoreWebuiMessageConstants.KW_EXC_USERNAME_IS_NULL;

    public static final String KW_LOG_INFO_CHECKING_PASSWORD = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_PASSWORD;

    public static final String KW_EXC_PASSWORD_IS_NULL = CoreWebuiMessageConstants.KW_EXC_PASSWORD_IS_NULL;

    public static final String KW_LOG_PASSED_NAVIAGTED_TO_AUTHENTICATED_PAGE = CoreWebuiMessageConstants.KW_LOG_PASSED_NAVIAGTED_TO_AUTHENTICATED_PAGE;

    public static final String KW_MSG_CANNOT_NAV_TO_AUTHENTICATED_PAGE = CoreWebuiMessageConstants.KW_MSG_CANNOT_NAV_TO_AUTHENTICATED_PAGE;

    public static final String KW_EXC_NO_IMAGE_FILE_PROP_IN_OBJ = CoreWebuiMessageConstants.KW_EXC_NO_IMAGE_FILE_PROP_IN_OBJ;

    public static final String KW_LOG_INFO_CLICKING_ON_IMG_X = CoreWebuiMessageConstants.KW_LOG_INFO_CLICKING_ON_IMG_X;

    public static final String KW_LOG_PASSED_CLICKED_IMG_X = CoreWebuiMessageConstants.KW_LOG_PASSED_CLICKED_IMG_X;

    public static final String KW_MSG_CANNOT_CLICK_ON_IMG = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLICK_ON_IMG;

    public static final String KW_MSG_CANNOT_CLICK_ON_IMG_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_CLICK_ON_IMG_X;

    public static final String KW_LOG_INFO_TYPING_ON_IMG_X = CoreWebuiMessageConstants.KW_LOG_INFO_TYPING_ON_IMG_X;

    public static final String KW_LOG_PASSED_TYPED_ON_IMG_X = CoreWebuiMessageConstants.KW_LOG_PASSED_TYPED_ON_IMG_X;

    public static final String KW_MSG_CANNOT_TYPE_ON_IMG = CoreWebuiMessageConstants.KW_MSG_CANNOT_TYPE_ON_IMG;

    public static final String KW_MSG_CANNOT_TYPE_ON_IMG_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_TYPE_ON_IMG_X;

    public static final String KW_LOG_INFO_WAITING_FOR_IMG_X_PRESENT = CoreWebuiMessageConstants.KW_LOG_INFO_WAITING_FOR_IMG_X_PRESENT;

    public static final String KW_LOG_PASSED_IMG_X_IS_PRESENT = CoreWebuiMessageConstants.KW_LOG_PASSED_IMG_X_IS_PRESENT;

    public static final String KW_LOG_PASSED_IMG_X_IS_NOT_PRESENT = CoreWebuiMessageConstants.KW_LOG_PASSED_IMG_X_IS_NOT_PRESENT;

    public static final String KW_MSG_IMG_X_IS_NOT_PRESENT = CoreWebuiMessageConstants.KW_MSG_IMG_X_IS_NOT_PRESENT;

    public static final String KW_MSG_CANNOT_VERIFY_IMG_X_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_IMG_X_PRESENT;

    public static final String KW_MSG_CANNOT_VERIFY_IMG_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_IMG_PRESENT;

    public static final String KW_MSG_CANNOT_WAIT_FOR_IMG_X_TOBE_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_IMG_X_TOBE_PRESENT;

    public static final String KW_MSG_CANNOT_WAIT_FOR_IMG_TOBE_PRESENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_FOR_IMG_TOBE_PRESENT;

    public static final String KW_LOG_INFO_OBJ_X_HAS_PARENT_FRAME = CoreWebuiMessageConstants.KW_LOG_INFO_OBJ_X_HAS_PARENT_FRAME;

    public static final String KW_LOG_INFO_SWITCHING_TO_IFRAME_X = CoreWebuiMessageConstants.KW_LOG_INFO_SWITCHING_TO_IFRAME_X;

    public static final String KW_LOG_INFO_SWITCHED_TO_IFRAME_X = CoreWebuiMessageConstants.KW_LOG_INFO_SWITCHED_TO_IFRAME_X;

    public static final String KW_LOG_FAILED_SWITCHED_TO_IFRAME = CoreWebuiMessageConstants.KW_LOG_FAILED_SWITCHED_TO_IFRAME;

    public static final String KW_LOG_FAILED_SWITCHED_TO_IFRAME_X = CoreWebuiMessageConstants.KW_LOG_FAILED_SWITCHED_TO_IFRAME_X;

    public static final String KW_LOG_INFO_SCROLLING_TO_OBJ_X = CoreWebuiMessageConstants.KW_LOG_INFO_SCROLLING_TO_OBJ_X;

    public static final String KW_LOG_PASSED_SCROLLING_TO_OBJ_X = CoreWebuiMessageConstants.KW_LOG_PASSED_SCROLLING_TO_OBJ_X;

    public static final String KW_MSG_CANNOT_SCROLLING_TO_OBJ_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_SCROLLING_TO_OBJ_X;

    public static final String KW_MSG_CANNOT_SCROLLING_TO_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_SCROLLING_TO_OBJ;
    
    
    public static final String KW_LOG_INFO_SCROLLING_FROM_OBJ = CoreWebuiMessageConstants.KW_LOG_INFO_SCROLLING_FROM_OBJ;

    public static final String KW_LOG_PASSED_SCROLLING_FROM_OBJ = CoreWebuiMessageConstants.KW_LOG_PASSED_SCROLLING_FROM_OBJ;

    public static final String KW_MSG_CANNOT_SCROLLING_FROM_OBJ = CoreWebuiMessageConstants.KW_MSG_CANNOT_SCROLLING_FROM_OBJ;
    
    
    public static final String KW_LOG_INFO_SCROLLING_FROM_OBJ_WITH_OFFSET = CoreWebuiMessageConstants.KW_LOG_INFO_SCROLLING_FROM_OBJ_WITH_OFFSET;

    public static final String KW_LOG_PASSED_SCROLLING_FROM_OBJ_WITH_OFFSET = CoreWebuiMessageConstants.KW_LOG_PASSED_SCROLLING_FROM_OBJ_WITH_OFFSET;

    public static final String KW_MSG_CANNOT_SCROLLING_FROM_OBJ_WITH_OFFSET = CoreWebuiMessageConstants.KW_MSG_CANNOT_SCROLLING_FROM_OBJ_WITH_OFFSET;
    
    
    public static final String KW_LOG_INFO_SCROLLING_FROM_POSITION = CoreWebuiMessageConstants.KW_LOG_INFO_SCROLLING_FROM_POSITION;

    public static final String KW_LOG_PASSED_SCROLLING_FROM_POSITION = CoreWebuiMessageConstants.KW_LOG_PASSED_SCROLLING_FROM_POSITION;

    public static final String KW_MSG_CANNOT_SCROLLING_FROM_POSITION = CoreWebuiMessageConstants.KW_MSG_CANNOT_SCROLLING_FROM_POSITION;


    public static final String KW_LOG_INFO_ELEMENT_RECT = "Element position in viewport: x = {0}, y = {1}, width = {2}, height = {3}";

    public static final String KW_LOG_INFO_VIEWPORT_RECT = "Viewport infomation: width = {0}, height = {1}";

    public static final String KW_LOG_PASSED_OBJ_X_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_VISIBLE_IN_VIEWPORT;

    public static final String KW_LOG_FAILED_OBJ_X_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_LOG_FAILED_OBJ_X_VISIBLE_IN_VIEWPORT;

    public static final String KW_MSG_PARENT_OBJECT_IS_NOT_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_MSG_PARENT_OBJECT_IS_NOT_VISIBLE_IN_VIEWPORT;

    public static final String KW_LOG_INFO_CHECKING_TO_IFRAME_X_IN_VIEWPORT = CoreWebuiMessageConstants.KW_LOG_INFO_CHECKING_TO_IFRAME_X_IN_VIEWPORT;

    public static final String KW_LOG_WARNING_OBJ_X_IS_NOT_PRESENT = CoreWebuiMessageConstants.KW_LOG_WARNING_OBJ_X_IS_NOT_PRESENT;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_VISIBLE_IN_VIEWPORT;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_VISIBLE_IN_VIEWPORT;

    public static final String KW_LOG_PASSED_OBJ_X_NOT_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_NOT_VISIBLE_IN_VIEWPORT;

    public static final String KW_LOG_FAILED_OBJ_X_NOT_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_LOG_FAILED_OBJ_X_NOT_VISIBLE_IN_VIEWPORT;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_NOT_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_NOT_VISIBLE_IN_VIEWPORT;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_NOT_VISIBLE_IN_VIEWPORT = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_NOT_VISIBLE_IN_VIEWPORT;

    public static final String KW_MSG_CANNOT_GET_VIEWPORT_WIDTH = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_VIEWPORT_WIDTH;

    public static final String KW_LOG_PASSED_GET_VIEWPORT_WIDTH_X = CoreWebuiMessageConstants.KW_LOG_PASSED_GET_VIEWPORT_WIDTH_X;

    public static final String KW_MSG_CANNOT_GET_VIEWPORT_HEIGHT = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_VIEWPORT_HEIGHT;

    public static final String KW_LOG_PASSED_GET_VIEWPORT_HEIGHT_X = CoreWebuiMessageConstants.KW_LOG_PASSED_GET_VIEWPORT_HEIGHT_X;

    public static final String KW_LOG_PASSED_OBJ_X_HAS_ATTRIBUTE_Y = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_HAS_ATTRIBUTE_Y;

    public static final String KW_LOG_FAILED_OBJ_X_HAS_ATTRIBUTE_Y = CoreWebuiMessageConstants.KW_LOG_FAILED_OBJ_X_HAS_ATTRIBUTE_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_HAS_ATTRIBUTE_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_HAS_ATTRIBUTE_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_HAS_ATTRIBUTE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_HAS_ATTRIBUTE;

    public static final String COMM_LOG_INFO_CHECKING_ATTRIBUTE_NAME = CoreWebuiMessageConstants.COMM_LOG_INFO_CHECKING_ATTRIBUTE_NAME;

    public static final String COMM_EXC_ATTRIBUTE_NAME_IS_NULL = CoreWebuiMessageConstants.COMM_EXC_ATTRIBUTE_NAME_IS_NULL;

    public static final String KW_LOG_PASSED_OBJ_X_NOT_HAS_ATTRIBUTE_Y = KW_LOG_FAILED_OBJ_X_HAS_ATTRIBUTE_Y;

    public static final String KW_LOG_FAILED_OBJ_X_NOT_HAS_ATTRIBUTE_Y = KW_LOG_PASSED_OBJ_X_HAS_ATTRIBUTE_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_NOT_HAS_ATTRIBUTE_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_NOT_HAS_ATTRIBUTE_Y;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_NOT_HAS_ATTRIBUTE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_NOT_HAS_ATTRIBUTE;

    public static final String KW_LOG_PASSED_OBJ_X_ATTRIBUTE_Y_VALUE_Z = CoreWebuiMessageConstants.KW_LOG_PASSED_OBJ_X_ATTRIBUTE_Y_VALUE_Z;

    public static final String KW_LOG_FAILED_OBJ_X_ATTRIBUTE_Y_ACTUAL_VALUE_Z_EXPECTED_VALUE_W = CoreWebuiMessageConstants.KW_LOG_FAILED_OBJ_X_ATTRIBUTE_Y_ACTUAL_VALUE_Z_EXPECTED_VALUE_W;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_X_ATTRIBUTE_Y_VALUE_Z = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_X_ATTRIBUTE_Y_VALUE_Z;

    public static final String KW_MSG_CANNOT_VERIFY_OBJ_ATTRIBUTE_VALUE = CoreWebuiMessageConstants.KW_MSG_CANNOT_VERIFY_OBJ_ATTRIBUTE_VALUE;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_HAS_ATTRIBUTE_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_HAS_ATTRIBUTE_Y;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_HAS_ATTRIBUTE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_HAS_ATTRIBUTE;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_NOT_HAS_ATTRIBUTE_Y = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_NOT_HAS_ATTRIBUTE_Y;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_NOT_HAS_ATTRIBUTE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_NOT_HAS_ATTRIBUTE;

    public static final String KW_LOG_FAILED_WAIT_FOR_OBJ_X_HAS_ATTRIBUTE_Y_VALUE_Z = CoreWebuiMessageConstants.KW_LOG_FAILED_WAIT_FOR_OBJ_X_HAS_ATTRIBUTE_Y_VALUE_Z;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_X_ATTRIBUTE_Y_VALUE_Z = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_X_ATTRIBUTE_Y_VALUE_Z;

    public static final String KW_MSG_CANNOT_WAIT_OBJ_ATTRIBUTE_VALUE = CoreWebuiMessageConstants.KW_MSG_CANNOT_WAIT_OBJ_ATTRIBUTE_VALUE;

    public static final String KW_LOG_PASSED_SET_VIEWPORT_WIDTH_X_HEIGHT_Y = "Viewport is set to new size with width = {0} and height = {1}";
    
    public static final String KW_LOG_WARNING_SET_VIEWPORT_WIDTH_HEIGHT = "Viewport size mismatch ({0}x{1}). Trying to set it again.";

    public static final String KW_MSG_CANNOT_SET_VIEWPORT = CoreWebuiMessageConstants.KW_MSG_CANNOT_SET_VIEWPORT;

    public static final String COMM_LOG_INFO_CHECKING_WIDTH = CoreWebuiMessageConstants.COMM_LOG_INFO_CHECKING_WIDTH;

    public static final String COMM_LOG_INFO_CHECKING_HEIGHT = CoreWebuiMessageConstants.COMM_LOG_INFO_CHECKING_HEIGHT;

    public static final String COMM_EXC_WIDTH_MUST_BE_ABOVE_ZERO = CoreWebuiMessageConstants.COMM_EXC_WIDTH_MUST_BE_ABOVE_ZERO;

    public static final String COMM_EXC_HEIGHT_MUST_BE_ABOVE_ZERO = CoreWebuiMessageConstants.COMM_EXC_HEIGHT_MUST_BE_ABOVE_ZERO;

    public static final String COMM_LOG_INFO_CHECKING_X = CoreWebuiMessageConstants.COMM_LOG_INFO_CHECKING_X;

    public static final String COMM_LOG_INFO_CHECKING_Y = CoreWebuiMessageConstants.COMM_LOG_INFO_CHECKING_Y;

    public static final String COMM_EXC_X_MUST_BE_ABOVE_ZERO = "X must be >= 0";

    public static final String COMM_EXC_Y_MUST_BE_ABOVE_ZERO = "Y must be >= 0";

    public static final String KW_LOG_PASSED_SCROLL_TO_POSITION_X_Y = "Browser is scrolled to position x = {0}, y = {1}";

    public static final String KW_MSG_CANNOT_SCROLL_TO_POSITION_X_Y = "Unable to scroll to position x = {0}, y = {1}";

    public static final String KW_LOG_INFO_SCROLLING_TO_POSITION_X_Y = "Scrolling to position x = {0}, y = {1}";

    public static final String KW_LOG_PASSED_GET_PAGE_WIDTH_X = CoreWebuiMessageConstants.KW_LOG_PASSED_GET_PAGE_WIDTH_X;

    public static final String KW_MSG_CANNOT_GET_PAGE_WIDTH = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_PAGE_WIDTH;

    public static final String KW_LOG_PASSED_GET_PAGE_HEIGHT_X = CoreWebuiMessageConstants.KW_LOG_PASSED_GET_PAGE_HEIGHT_X;

    public static final String KW_MSG_CANNOT_GET_PAGE_HEIGHT = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_PAGE_HEIGHT;

    public static final String KW_LOG_PASSED_GET_VIEWPORT_LEFT_POSITION_X = CoreWebuiMessageConstants.KW_LOG_PASSED_GET_VIEWPORT_LEFT_POSITION_X;

    public static final String KW_MSG_CANNOT_GET_VIEWPORT_LEFT_POSITION = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_VIEWPORT_LEFT_POSITION;

    public static final String KW_LOG_PASSED_GET_VIEWPORT_TOP_POSITION_X = CoreWebuiMessageConstants.KW_LOG_PASSED_GET_VIEWPORT_TOP_POSITION_X;

    public static final String KW_MSG_CANNOT_GET_VIEWPORT_TOP_POSITION = CoreWebuiMessageConstants.KW_MSG_CANNOT_GET_VIEWPORT_TOP_POSITION;

    public static final String KW_LOG_INFO_INJECTED_INPUT = CoreWebuiMessageConstants.KW_LOG_INFO_INJECTED_INPUT;

    public static final String KW_LOG_INFO_EMITTED_DRAG_AND_DROP_EVENT = CoreWebuiMessageConstants.KW_LOG_INFO_EMITTED_DRAG_AND_DROP_EVENT;

    public static final String KW_CATEGORIZE_ALERT = "Alert";

    public static final String KW_CATEGORIZE_ATTRIBUTE = "Attribute";

    public static final String KW_CATEGORIZE_BROWSER = "Browser";

    public static final String KW_CATEGORIZE_CHECKBOX = "Checkbox";

    public static final String KW_CATEGORIZE_COMBOBOX = "Combo Box";

    public static final String KW_CATEGORIZE_ELEMENT = "Element";

    public static final String KW_CATEGORIZE_FORM = "Form";

    public static final String KW_CATEGORIZE_FRAME = "Frame";

    public static final String KW_CATEGORIZE_IMAGE = "Image";

    public static final String KW_CATEGORIZE_KEYBOARD = "Keyboard";

    public static final String KW_CATEGORIZE_TEXT = "Text";

    public static final String KW_CATEGORIZE_WINDOW = "Window";

    public static final String KW_CATEGORIZE_UTILITIES = "Utilities";

    // WebUiDriverPropertySettingStore
    public static final String WEB_UI_PROPERTY_FILE_NAME = "com.kms.katalon.core.webui";

    public static final String KW_LOG_WEB_UI_PROPERTY_SETTING = CoreWebuiMessageConstants.KW_LOG_WEB_UI_PROPERTY_SETTING;

    public static final String KW_LOG_FIREFOX_PROPERTY_SETTING = CoreWebuiMessageConstants.KW_LOG_FIREFOX_PROPERTY_SETTING;

    // WebMobileDriverFactory
    public static final String APPIUM_START_EXCEPTION_APPIUM_DIRECTORY_NOT_SET = CoreWebuiMessageConstants.APPIUM_START_EXCEPTION_APPIUM_DIRECTORY_NOT_SET;

    public static final String APPIUM_START_EXCEPTION_APPIUM_DIRECTORY_INVALID_CANNOT_FIND_APPIUM_JS = CoreWebuiMessageConstants.APPIUM_START_EXCEPTION_APPIUM_DIRECTORY_INVALID_CANNOT_FIND_APPIUM_JS;

    public static final String SET_ENCRYPTED_TEXT_KEYWORD = "setEncryptedText";

    public static final String KW_LOG_INFO_DEFAULT_LOCATOR_FAILED_TRY_SELF_HEALING = CoreWebuiMessageConstants.KW_LOG_INFO_DEFAULT_LOCATOR_FAILED_TRY_SELF_HEALING;

    public static final String KW_LOG_INFO_PROPOSE_ALTERNATE_LOCATOR = CoreWebuiMessageConstants.KW_LOG_INFO_PROPOSE_ALTERNATE_LOCATOR;

    public static final String KW_LOG_INFO_SMART_XPATHS_SUPPORT_START = CoreWebuiMessageConstants.KW_LOG_INFO_SMART_XPATHS_SUPPORT_START;

    public static final String KW_LOG_INFO_SELF_HEALING_USING = CoreWebuiMessageConstants.KW_LOG_INFO_SELF_HEALING_USING;

    public static final String KW_LOG_INFO_SMART_XPATHS_AUTO_UPDATE_AND_CONTINUE_EXECUTION = CoreWebuiMessageConstants.KW_LOG_INFO_SMART_XPATHS_AUTO_UPDATE_AND_CONTINUE_EXECUTION;

    public static final String KW_LOG_INFO_SMART_XPATHS_SUPPORT_END = CoreWebuiMessageConstants.KW_LOG_INFO_SMART_XPATHS_SUPPORT_END;

    public static final String KW_LOG_INFO_USING_HEURISTIC_METHOD = CoreWebuiMessageConstants.KW_LOG_INFO_USING_HEURISTIC_METHOD;

    public static final String KW_LOG_INFO_SCREENSHOTS_BY_SMART_XPATH_ARE_SAVED = CoreWebuiMessageConstants.KW_LOG_INFO_SCREENSHOTS_BY_SMART_XPATH_ARE_SAVED;

    public static final String KW_LOG_INFO_COULD_NOT_SAVE_SCREENSHOT = CoreWebuiMessageConstants.KW_LOG_INFO_COULD_NOT_SAVE_SCREENSHOT;

    public static final String KW_LOG_INFO_SELECT_SMART_XPATH = CoreWebuiMessageConstants.KW_LOG_INFO_SELECT_SMART_XPATH;

    public static final String KW_LOG_INFO_COULD_NOT_FIND_ANY_WEB_ELEMENT_WITH_SMART_XPATHS = CoreWebuiMessageConstants.KW_LOG_INFO_COULD_NOT_FIND_ANY_WEB_ELEMENT_WITH_SMART_XPATHS;

    // Screenshot keyword
    public static final String KW_LOG_INFO_SCREENSHOT_FULLPAGE_FAIL_HIDE_OBJECT = CoreWebuiMessageConstants.KW_LOG_INFO_SCREENSHOT_FULLPAGE_FAIL_HIDE_OBJECT;

    public static final String KW_LOG_INFO_SCREENSHOT_FULLPAGE_FAIL_HIDE_OBJECT_OUT_OF_IMAGE = CoreWebuiMessageConstants.KW_LOG_INFO_SCREENSHOT_FULLPAGE_FAIL_HIDE_OBJECT_OUT_OF_IMAGE;

    public static final String KW_LOG_INFO_SCREENSHOT_FULLPAGE_HIDDEN_COUNTER = CoreWebuiMessageConstants.KW_LOG_INFO_SCREENSHOT_FULLPAGE_HIDDEN_COUNTER;

    public static final String KW_SCREENSHOT_EXCEPTION_FILENAME_NULL_EMPTY = CoreWebuiMessageConstants.KW_SCREENSHOT_EXCEPTION_FILENAME_NULL_EMPTY;

    public static final String KW_SCREENSHOT_EXCEPTION_ELEMENT_NULL = CoreWebuiMessageConstants.KW_SCREENSHOT_EXCEPTION_ELEMENT_NULL;

    public static final String KW_SCREENSHOT_EXCEPTION_AREA_NULL = CoreWebuiMessageConstants.KW_SCREENSHOT_EXCEPTION_AREA_NULL;

    public static final String KW_SCREENSHOT_EXCEPTION_AREA_LARGER = CoreWebuiMessageConstants.KW_SCREENSHOT_EXCEPTION_AREA_LARGER;

    public static final String KW_SCREENSHOT_EXCEPTION_WHILE_ADDING_TEXT = CoreWebuiMessageConstants.KW_SCREENSHOT_EXCEPTION_WHILE_ADDING_TEXT;

    public static final String KW_MSG_FOUND_WEB_ELEMENT = CoreWebuiMessageConstants.KW_MSG_FOUND_WEB_ELEMENT;

    public static final String KW_MSG_CANNOT_FIND_WEB_ELEMENT = CoreWebuiMessageConstants.KW_MSG_CANNOT_FIND_WEB_ELEMENT;

    public static final String KW_MSG_CANNOT_FIND_WEB_ELEMENT_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_FIND_WEB_ELEMENT_X;

    public static final String KW_MSG_FOUND_WEB_ELEMENTS = CoreWebuiMessageConstants.KW_MSG_FOUND_WEB_ELEMENTS;

    public static final String KW_MSG_CANNOT_FIND_WEB_ELEMENTS = CoreWebuiMessageConstants.KW_MSG_CANNOT_FIND_WEB_ELEMENTS;

    public static final String KW_MSG_CANNOT_FIND_WEB_ELEMENTS_X = CoreWebuiMessageConstants.KW_MSG_CANNOT_FIND_WEB_ELEMENTS_X;
}
