package com.kms.katalon.core.webui.driver.chromium;

import com.kms.katalon.core.webui.driver.AbstractDriverBuilder;
import com.kms.katalon.core.webui.driver.WebUIDriverType;
import com.kms.katalon.core.webui.util.FileUtil;
import com.kms.katalon.core.webui.util.WebDriverPropertyUtil;
import org.openqa.selenium.chromium.ChromiumOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;

import java.io.File;
import java.io.IOException;

public abstract class ChromiumDriverBuilder extends AbstractDriverBuilder {

    @Override
    protected boolean canUseBiDi() {
        return true;
    }

    protected AbstractDriverOptions<?> addExtension(AbstractDriverOptions<?> options, String extensionPath) throws IOException {
        boolean installedKcu = WebDriverPropertyUtil
                .didUserProfileInstallKatalonCompactUtility(WebUIDriverType.CHROME_DRIVER, capabilities);

        if (installedKcu) {
            return options;
        }

        if (!(options instanceof ChromiumOptions<?> chromiumOptions)) {
            return options;
        }

        var extension = new File(FileUtil.getExtensionsDirectory(), extensionPath);
        chromiumOptions.addExtensions(extension);
        return chromiumOptions;
    }
}
