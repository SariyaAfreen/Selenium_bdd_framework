package com.kms.katalon.core.webui.driver;

import org.openqa.selenium.WebDriver;

public class MobileDriverBuilder extends BaseDriverBuilder {

    private WebUIDriverType driverType;

    public IDriverBuilder driverType(WebUIDriverType driverType) {
        this.driverType = driverType;
        return this;
    }

    @Override
    public WebDriver build() throws Exception {
        return WebMobileDriverFactory.createMobileDriver(driverType);
    }
}
