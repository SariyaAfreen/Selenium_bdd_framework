package com.kms.katalon.core.webui.driver.edge;

import com.kms.katalon.core.configuration.RunConfiguration;
import com.kms.katalon.core.webui.driver.AbstractDriverBuilder;
import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.util.OSUtil;
import com.kms.katalon.selenium.driver.CEdgeDriver;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriverService;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;

import java.io.File;

public class EdgeDriverBuilder extends AbstractDriverBuilder {

    @Override
    protected AbstractDriverOptions<?> createOptions(Capabilities capabilities) {
        return new EdgeOptions().merge(capabilities);
    }

    @Override
    protected WebDriver createDriver(AbstractDriverOptions<?> options) {
        if (!(options instanceof EdgeOptions edgeOptions)) {
            return null;
        }

        var service = new EdgeDriverService.Builder()
                .usingDriverExecutable(new File(EdgeDriverUtil.getEdgeDriverPath()))
                .usingAnyFreePort()
                .build();
        return new CEdgeDriver(service, edgeOptions, driverConfigProvider.getActionDelayInMilisecond());
    }
}
