package com.kms.katalon.core.webui.driver.ie;

import com.kms.katalon.core.configuration.RunConfiguration;
import com.kms.katalon.core.webui.constants.StringConstants;
import com.kms.katalon.core.webui.driver.AbstractDriverBuilder;
import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.util.OSUtil;
import com.kms.katalon.selenium.driver.CInternetExplorerDriver;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriverLogLevel;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;

import java.io.File;

public class InternetExplorerDriverBuilder extends AbstractDriverBuilder {

    private static final String USE_PER_PROCESS_PROXY_CAP = "ie.usePerProcessProxy";

    private static final String DRIVER_SERVER_LOG_FILE_NAME = "IEDriverServer.log";

    public static final String DRIVER_PATH_PROPERTY = StringConstants.CONF_PROPERTY_IE_DRIVER_PATH;

    @Override
    protected AbstractDriverOptions<?> createOptions(Capabilities capabilities) {
        var options = new InternetExplorerOptions(capabilities);
        options.setCapability(USE_PER_PROCESS_PROXY_CAP, "true");
        return options;
    }

    @Override
    protected WebDriver createDriver(AbstractDriverOptions<?> options) {
        if (!(options instanceof InternetExplorerOptions internetExplorerOptions)) {
            return null;
        }

        var logPath = RunConfiguration.getLogFolderPath() + File.separator + DRIVER_SERVER_LOG_FILE_NAME;
        var service = new InternetExploreDriverServiceBuilder()
                .withLogLevel(InternetExplorerDriverLogLevel.TRACE)
                .usingDriverExecutable(new File(getDriverPath()))
                .withLogFile(new File(logPath))
                .build();

        return new CInternetExplorerDriver(service, internetExplorerOptions, driverConfigProvider.getActionDelayInMilisecond());
    }

    private static String getDriverPath() {
        if (OSUtil.is64Bit()) {
            File location = new File(RunConfiguration.getProjectDir(),
                    "Include/drivers/iedriver_win64/IEDriverServer.exe");
            if (location.exists()) {
                logger.logInfo("Custom IEDriverServer detected at location: " + location.getAbsolutePath());
                return location.getAbsolutePath();
            }
        } else {
            File location = new File(RunConfiguration.getProjectDir(),
                    "Include/drivers/iedriver_win32/IEDriverServer.exe");
            if (location.exists()) {
                logger.logInfo(
                        "Custom IEDriverServer detected at location: " + location.getAbsolutePath());
                return location.getAbsolutePath();
            }
        }

        return RunConfiguration.getDriverSystemProperty(DriverFactory.WEB_UI_DRIVER_PROPERTY, DRIVER_PATH_PROPERTY);
    }
}
