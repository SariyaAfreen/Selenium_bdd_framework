package com.kms.katalon.core.webui.driver;

import com.kms.katalon.core.logging.KeywordLogger;
import com.kms.katalon.core.webui.util.FileUtil;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.bidi.module.Script;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;

import java.io.File;
import java.io.IOException;

public abstract class BaseDriverBuilder implements IDriverBuilder {

    protected static final KeywordLogger logger = KeywordLogger.getInstance(DriverFactory.class);
    protected static final IDriverConfigurationProvider driverConfigProvider = new DriverConfigurationProvider(logger);

    protected Capabilities capabilities = new MutableCapabilities();
    protected boolean withSmartWait = false;
    protected boolean withSmartLocator = false;

    @Override
    public IDriverBuilder capabilities(Capabilities capabilities) {
        this.capabilities = capabilities;
        return this;
    }

    @Override
    public IDriverBuilder withSmartWait(boolean value) {
        this.withSmartWait = value;
        return this;
    }

    @Override
    public IDriverBuilder withSmartLocator(boolean value) {
        this.withSmartLocator = value;
        return this;
    }
}
