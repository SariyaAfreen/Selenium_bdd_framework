package com.kms.katalon.core.webui.driver.chrome;

import com.kms.katalon.core.configuration.RunConfiguration;
import com.kms.katalon.core.logging.KeywordLogger;
import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.util.FileExcutableUtil;
import com.kms.katalon.core.webui.util.OSUtil;

import java.io.File;
import java.io.IOException;

public class ChromeDriverUtil {
    protected static final KeywordLogger logger = KeywordLogger.getInstance(DriverFactory.class);

    public static String getChromeDriverPath() {
        if (OSUtil.isWindows()) {
            if (OSUtil.is64Bit()) {
                File location = new File(RunConfiguration.getProjectDir(),
                        "Include/drivers/chromedriver_win64/chromedriver.exe");
                if (location.exists()) {
                    logger.logInfo("Custom Chrome detected at location: " + location.getAbsolutePath());
                    return location.getAbsolutePath();
                }
            } else {
                File location = new File(RunConfiguration.getProjectDir(),
                        "Include/drivers/chromedriver_win32/chromedriver.exe");
                if (location.exists()) {
                    logger.logInfo(
                            "Custom Chrome detected at location: " + location.getAbsolutePath());
                    return location.getAbsolutePath();
                }
            }
        } else if (OSUtil.isMac()) {
            File location = new File(RunConfiguration.getProjectDir(),
                    "Include/drivers/chromedriver_mac64/chromedriver");
            String chromeDriverPath = location.getAbsolutePath();
            if (location.exists()) {
                try {
                    logger.logInfo("Custom Chrome detected at location: " + location.getAbsolutePath());
                    FileExcutableUtil.makeFileExecutable(chromeDriverPath);
                } catch (IOException e) {
                    logger.logInfo("Cannot make Chrome driver file: " + location.getAbsolutePath()
                            + "executable");
                }
                return location.getAbsolutePath();
            }
        } else {
            if (OSUtil.is64Bit()) {
                File location = new File(RunConfiguration.getProjectDir(),
                        "Include/drivers/chromedriver_linux64/chromedriver");
                String chromeDriverPath = location.getAbsolutePath();
                if (location.exists()) {
                    try {
                        logger.logInfo(
                                "Custom Chrome detected at location: " + location.getAbsolutePath());
                        FileExcutableUtil.makeFileExecutable(chromeDriverPath);
                    } catch (IOException e) {
                        logger.logInfo("Cannot make Chrome driver file:" + location.getAbsolutePath()
                                + " executable");
                    }
                    return location.getAbsolutePath();
                }
            } else {
                File location = new File(RunConfiguration.getProjectDir(),
                        "Include/drivers/chromedriver_linux32/chromedriver");
                String chromeDriverPath = location.getAbsolutePath();
                if (location.exists()) {
                    try {
                        logger.logInfo(
                                "Custom Chrome detected at location: " + location.getAbsolutePath());
                        FileExcutableUtil.makeFileExecutable(chromeDriverPath);
                    } catch (IOException e) {
                        logger.logInfo("Cannot make Chrome driver file:" + location.getAbsolutePath()
                                + "executable");
                    }
                    return location.getAbsolutePath();
                }
            }
        }

        return RunConfiguration.getDriverSystemProperty(DriverFactory.WEB_UI_DRIVER_PROPERTY, DriverFactory.CHROME_DRIVER_PATH_PROPERTY);
    }
}
