package com.kms.katalon.core.webui.driver.chrome;

import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.driver.chromium.ChromiumDriverBuilder;
import com.kms.katalon.selenium.driver.CChromeDriver;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;

import java.io.File;
import java.io.IOException;

public class ChromeDriverBuilder extends ChromiumDriverBuilder {

    private static final String SMART_WAIT_ADDON_PATH = "Smart Wait.zip";
    private static final String SMART_LOCATOR_ADDON_PATH = "Smart Locator.zip";

    @Override
    protected AbstractDriverOptions<?> createOptions(Capabilities capabilities) {
        return new ChromeOptions().merge(capabilities);
    }

    @Override
    protected AbstractDriverOptions<?> addSmartWaitExtension(AbstractDriverOptions<?> options) throws IOException {
        return addExtension(options, SMART_WAIT_ADDON_PATH);
    }

    @Override
    protected AbstractDriverOptions<?> addSmartLocatorExtension(AbstractDriverOptions<?> options) throws IOException {
        return addExtension(options, SMART_LOCATOR_ADDON_PATH);
    }

    @Override
    protected WebDriver createDriver(AbstractDriverOptions<?> options) {
        if (!(options instanceof ChromeOptions chromeOptions)) {
            return null;
        }

        System.setProperty(DriverFactory.CHROME_DRIVER_PATH_PROPERTY_KEY, ChromeDriverUtil.getChromeDriverPath());
        return new CChromeDriver(chromeOptions, driverConfigProvider.getActionDelayInMilisecond());
    }
}
