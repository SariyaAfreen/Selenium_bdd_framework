package com.kms.katalon.core.webui.driver.edge;

import com.kms.katalon.core.webui.driver.chromium.ChromiumDriverBuilder;
import com.kms.katalon.selenium.driver.CEdgeDriver;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriverService;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;

import java.io.File;
import java.io.IOException;

public class EdgeChromiumDriverBuilder extends ChromiumDriverBuilder {

    private static final String SMART_WAIT_ADDON_PATH = "Smart Wait.zip";
    private static final String SMART_LOCATOR_ADDON_PATH = "Smart Locator.zip";

    @Override
    protected AbstractDriverOptions<?> createOptions(Capabilities capabilities) {
        return new EdgeOptions().merge(capabilities);
    }

    @Override
    protected AbstractDriverOptions<?> addSmartWaitExtension(AbstractDriverOptions<?> options) throws IOException {
        return addExtension(options, SMART_WAIT_ADDON_PATH);
    }

    @Override
    protected AbstractDriverOptions<?> addSmartLocatorExtension(AbstractDriverOptions<?> options) throws IOException {
        return addExtension(options, SMART_LOCATOR_ADDON_PATH);
    }

    @Override
    protected WebDriver createDriver(AbstractDriverOptions<?> options) {
        if (!(options instanceof EdgeOptions edgeOptions)) {
            return null;
        }

        var service = new EdgeDriverService.Builder()
                .usingDriverExecutable(new File(EdgeDriverUtil.getEdgeChromiumDriverPath()))
                .usingAnyFreePort()
                .build();
        return new CEdgeDriver(service, edgeOptions, driverConfigProvider.getActionDelayInMilisecond());
    }
}
