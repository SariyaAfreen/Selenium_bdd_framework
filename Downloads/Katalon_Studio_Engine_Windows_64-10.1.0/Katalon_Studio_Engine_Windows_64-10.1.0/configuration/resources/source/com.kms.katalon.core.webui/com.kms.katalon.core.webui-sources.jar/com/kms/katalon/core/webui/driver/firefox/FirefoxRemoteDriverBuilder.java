package com.kms.katalon.core.webui.driver.firefox;

import com.kms.katalon.core.configuration.RunConfiguration;
import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.driver.remote.AbstractRemoteDriverBuilder;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

public class FirefoxRemoteDriverBuilder extends AbstractRemoteDriverBuilder {

    @Override
    protected AbstractDriverOptions<?> createOptions(Capabilities capabilities) {
        return new FirefoxOptions(capabilities);
    }

    @Override
    protected WebDriver createDriver(AbstractDriverOptions<?> options) throws Exception {
        if (!(options instanceof FirefoxOptions firefoxOptions)) {
            return null;
        }

        var debugHost = RunConfiguration.getDriverSystemProperty(DriverFactory.WEB_UI_DRIVER_PROPERTY, DriverFactory.DEBUG_HOST,
                DriverFactory.DEFAULT_DEBUG_HOST);
        var debugPort = RunConfiguration.getDriverSystemProperty(DriverFactory.WEB_UI_DRIVER_PROPERTY, DriverFactory.DEBUG_PORT,
                DriverFactory.DEFAULT_FIREFOX_DEBUG_PORT);
        var driverUrl = new URL("http", debugHost, Integer.parseInt(debugPort), "/hub");

        waitForRemoteBrowserReady(driverUrl);
        return new RemoteWebDriver(driverUrl, firefoxOptions);
    }
}
