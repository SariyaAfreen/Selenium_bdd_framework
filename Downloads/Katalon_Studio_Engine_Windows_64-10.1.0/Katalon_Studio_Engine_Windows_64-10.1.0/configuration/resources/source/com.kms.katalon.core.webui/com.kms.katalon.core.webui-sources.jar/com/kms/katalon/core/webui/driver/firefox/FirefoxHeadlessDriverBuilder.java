package com.kms.katalon.core.webui.driver.firefox;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.AbstractDriverOptions;

public class FirefoxHeadlessDriverBuilder extends FirefoxDriverBuilder {

    @Override
    protected AbstractDriverOptions<?> createOptions(Capabilities capabilities) {
        var options = super.createOptions(capabilities);

        if (options instanceof FirefoxOptions firefoxOptions) {
            firefoxOptions.addArguments("--headless");
        }

        return options;
    }
}
