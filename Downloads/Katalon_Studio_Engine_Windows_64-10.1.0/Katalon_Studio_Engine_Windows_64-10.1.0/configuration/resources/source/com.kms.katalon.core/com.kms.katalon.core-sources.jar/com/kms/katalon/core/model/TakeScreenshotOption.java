package com.kms.katalon.core.model;

public enum TakeScreenshotOption {
    NONE, FAILED_STEPS, ALL_STEPS
}
