package com.kms.katalon.core.testobject;

public enum RequestObjectType {
    RESTFUL("RESTful"), SOAP("SOAP");

    private String name;

    RequestObjectType(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
