package com.kms.katalon.core.testobject;

public enum SelectorMethod {
    BASIC("Attributes"),
    XPATH("XPath"),
    CSS("CSS"),
    IMAGE("Image"),
    SMART_LOCATOR("Smart Locator");

    private String name;

    private SelectorMethod(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
