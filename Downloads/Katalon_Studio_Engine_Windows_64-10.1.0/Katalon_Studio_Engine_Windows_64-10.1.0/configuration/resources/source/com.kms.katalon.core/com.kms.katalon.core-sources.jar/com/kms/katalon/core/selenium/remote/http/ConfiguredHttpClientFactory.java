package com.kms.katalon.core.selenium.remote.http;

import java.io.IOException;
import java.net.Proxy;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.remote.http.ClientConfig;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpClient.Factory;
import org.openqa.selenium.remote.http.jdk.JdkHttpClient;

import com.kms.katalon.core.network.ProxyInformation;
import com.kms.katalon.core.network.ProxyOption;
import com.kms.katalon.core.util.internal.ProxyUtil;

public class ConfiguredHttpClientFactory implements Factory {

    private static final String JDK_HTTP_AUTH_TUNNELING_DISABLED_SCHEMES = "jdk.http.auth.tunneling.disabledSchemes";

    private JdkHttpClient.Factory factory = new JdkHttpClient.Factory();

    private Proxy proxy;

    private String proxyUsername;

    private String proxyPassword;

    public static ConfiguredHttpClientFactory of(ProxyInformation proxyInfo, URL url) throws URISyntaxException, IOException {
        var proxy = ProxyUtil.getProxy(proxyInfo, url);

        if (proxyInfo.getProxyOption().equals(ProxyOption.MANUAL_CONFIG.name())) {
            return new ConfiguredHttpClientFactory(proxy, proxyInfo.getUsername(), proxyInfo.getPassword());
        }

        return new ConfiguredHttpClientFactory(proxy);
    }

    public ConfiguredHttpClientFactory(Proxy proxy) {
        this(proxy, null, null);
    }

    public ConfiguredHttpClientFactory(Proxy proxy, String proxyUsername, String proxyPassword) {
        this.proxy = proxy;
        this.proxyUsername = proxyUsername;
        this.proxyPassword = proxyPassword;
    }

    @Override
    public HttpClient createClient(ClientConfig config) {
        if (proxy == null) {
            return factory.createClient(config);
        }

        ClientConfig proxyInstance = config.proxy(proxy);

        /**
         * We add the Proxy-Authorization header directly via the filter
         * {@link com.kms.katalon.selenium.filter.SeleniumProxyBasicAuthorizationFilter}
         * 
         */
        // if (!StringUtils.isEmpty(proxyUsername)) {
        // proxyInstance = proxyInstance.authenticateAs(new UsernameAndPassword(proxyUsername, proxyPassword));
        // }

        /**
         * We have change the JVM
         * system property <b>jdk.http.auth.tunneling.disabledSchemes</b> from
         * default value <b>Basic</> to empty in order to use Basic for proxy tunnel
         * </br>
         * 
         * @see <a href=
         * "https://docs.oracle.com/en/java/javase/16/core/networking-properties.html#:~:text=jdk.http.auth.tunneling.disabledSchemes">Java
         * Networking System Properties</a>
         */
        if (StringUtils.isNotBlank(proxyUsername) && StringUtils.isNotBlank(proxyPassword)) {
            String disabledSchemesValue = System.getProperty(JDK_HTTP_AUTH_TUNNELING_DISABLED_SCHEMES);
            System.setProperty(JDK_HTTP_AUTH_TUNNELING_DISABLED_SCHEMES, "");

            HttpClient client = factory.createClient(proxyInstance);

            if (null != disabledSchemesValue) {
                System.setProperty(JDK_HTTP_AUTH_TUNNELING_DISABLED_SCHEMES, disabledSchemesValue);
            } else {
                System.clearProperty(JDK_HTTP_AUTH_TUNNELING_DISABLED_SCHEMES);
            }

            return client;
        } else {
            return factory.createClient(proxyInstance);
        }
    }

    @Override
    public void cleanupIdleClients() {
        factory.cleanupIdleClients();
    }
}
