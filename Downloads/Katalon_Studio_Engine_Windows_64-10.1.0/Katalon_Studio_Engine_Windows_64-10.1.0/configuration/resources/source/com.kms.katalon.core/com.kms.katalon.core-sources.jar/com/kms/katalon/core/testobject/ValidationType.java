package com.kms.katalon.core.testobject;

public enum ValidationType {
    AUTO_DETECT("Auto Detect"),
    JSON_SCHEMA("JSON"),
    XML_SCHEMA("XML"),
    OPEN_API_SPEC("OpenAPI/Swagger"),
    GRAPHQL_SCHEMA("GraphQL");

    private String name;

    ValidationType(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
