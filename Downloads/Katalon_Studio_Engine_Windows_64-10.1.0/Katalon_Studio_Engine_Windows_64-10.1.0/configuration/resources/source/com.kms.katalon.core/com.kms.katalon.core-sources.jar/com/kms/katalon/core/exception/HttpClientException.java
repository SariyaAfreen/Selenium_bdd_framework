package com.kms.katalon.core.exception;

public class HttpClientException extends Exception {
    private static final long serialVersionUID = 8383665386658750568L;

    public HttpClientException(Throwable e) {
        super(e);
    }

    public HttpClientException(String message) {
        super(message);
    }

    @Override
    public synchronized Throwable getCause() {
        return super.getCause();
    }

    public static HttpClientException wrap(Exception e) {
        if (e instanceof HttpClientException) {
            return (HttpClientException) e;
        } else {
            return new HttpClientException(e);
        }
    }
}
