package com.kms.katalon.core.testobject;

public enum ValidationDataType {
    AUTO("Auto Detect"), FILE("File"), URL("URL");

    private String name;

    ValidationDataType(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
