package com.kms.katalon.core.testobject;

public enum ValidationStatus {
    PASS("Pass"), FAIL("Fail"), ERROR("Error"), WARNING("Warning"), SKIP("Skip");

    private String name;

    ValidationStatus(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
