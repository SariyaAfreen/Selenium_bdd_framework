package com.kms.katalon.core.http;

import com.google.common.escape.Escaper;
import com.google.common.net.PercentEscaper;

public class HttpUtils {

    private static final Escaper PATH_ESCAPER = new PercentEscaper("-_.*", false);

    public static String escapePathSegment(String value) {
        return PATH_ESCAPER.escape(value);
    }
}
