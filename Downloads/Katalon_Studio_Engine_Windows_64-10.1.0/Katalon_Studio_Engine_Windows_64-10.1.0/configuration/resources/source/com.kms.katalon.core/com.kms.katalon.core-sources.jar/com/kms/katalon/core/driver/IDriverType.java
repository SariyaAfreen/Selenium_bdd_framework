package com.kms.katalon.core.driver;

public interface IDriverType {
	String getName();

	String getPropertyKey();

	String getPropertyValue();
}