package com.kms.katalon.core.exception;

public class InternalServerException extends Exception {

    private static final long serialVersionUID = 1L;
    
    private int statusCode;

    public InternalServerException(Throwable e) {
        super(e);
    }

    public InternalServerException(String message) {
        super(message);
    }
    
    public InternalServerException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }

    @Override
    public synchronized Throwable getCause() {
        return super.getCause();
    }

    public static HttpClientException wrap(Exception e) {
        if (e instanceof HttpClientException) {
            return (HttpClientException) e;
        } else {
            return new HttpClientException(e);
        }
    }

    public int getStatusCode() {
        return statusCode;
    }
}
