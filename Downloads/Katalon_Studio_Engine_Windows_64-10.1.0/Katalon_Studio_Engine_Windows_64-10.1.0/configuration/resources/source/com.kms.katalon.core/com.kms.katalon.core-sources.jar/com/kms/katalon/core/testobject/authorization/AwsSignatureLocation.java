package com.kms.katalon.core.testobject.authorization;

public enum AwsSignatureLocation {
    REQUEST_HEADER("Request Headers"),
    QUERY_STRING("Request URL");
    
    private final String displayName;

    private AwsSignatureLocation(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
