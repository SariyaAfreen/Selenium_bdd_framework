package com.kms.katalon.core.testobject.authentication;

public class OAuth2Entity {
	private String grantType;

	private String userName;

	private String password;

	private String callbackUrl;

	private String authUrl;

	private String accessTokenUrl;

	private String state;

	private String consumerKey;

	private String consumerSecret;

	private String authorizationCode;

	private String scope;

	private String accessToken;

	private String refreshToken;

	private String tokenType;

	public OAuth2Entity() {
	}

	public OAuth2Entity(String grantType, String accessTokenUrl, String state, String consumerKey,
			String consumerSecret, String authorizationCode, String scope, String accessToken, String refreshToken,
			String tokenType) {
		super();
		this.grantType = grantType;
		this.accessTokenUrl = accessTokenUrl;
		this.state = state;
		this.consumerKey = consumerKey;
		this.consumerSecret = consumerSecret;
		this.authorizationCode = authorizationCode;
		this.scope = scope;
		this.accessToken = accessToken;
		this.refreshToken = refreshToken;
		this.tokenType = tokenType;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public void setAuthUrl(String authUrl) {
		this.authUrl = authUrl;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public String getGrantType() {
		return grantType;
	}

	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}

	public String getAccessTokenUrl() {
		return accessTokenUrl;
	}

	public void setAccessTokenUrl(String accessTokenUrl) {
		this.accessTokenUrl = accessTokenUrl;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getConsumerKey() {
		return consumerKey;
	}

	public void setConsumerKey(String consumerKey) {
		this.consumerKey = consumerKey;
	}

	public String getConsumerSecret() {
		return consumerSecret;
	}

	public void setConsumerSecret(String consumerSecret) {
		this.consumerSecret = consumerSecret;
	}

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getTokenType() {
		return tokenType;
	}

	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public String getAuthUrl() {
		return authUrl;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

}
