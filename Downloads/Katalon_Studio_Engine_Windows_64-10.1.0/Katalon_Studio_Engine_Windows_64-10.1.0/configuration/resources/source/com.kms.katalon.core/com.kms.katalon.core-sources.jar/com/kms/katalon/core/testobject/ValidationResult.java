package com.kms.katalon.core.testobject;

import java.io.Serializable;

public class ValidationResult implements Serializable {
    private static final long serialVersionUID = 1L;

    public String message;

    public ValidationStatus status;

    public ValidationResult() {
        super();
    }

    public ValidationResult(ValidationStatus status) {
        super();
        this.status = status;
    }

    public ValidationResult(String message, ValidationStatus status) {
        super();
        this.message = message;
        this.status = status;
    }
}
