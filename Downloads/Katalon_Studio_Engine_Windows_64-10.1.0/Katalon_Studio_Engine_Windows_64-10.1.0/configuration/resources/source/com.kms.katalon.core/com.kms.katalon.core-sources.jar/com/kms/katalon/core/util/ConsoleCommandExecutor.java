package com.kms.katalon.core.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;

import com.kms.katalon.core.util.internal.ProcessUtil;

public class ConsoleCommandExecutor {
    private static final String PATH = "PATH";

    private static final String PATH_SEPARATOR = ":";

    private static final String MAC_PATH_ENV_FILE = "/etc/paths";

    private static final String LINUX_ENV_FILE = "/etc/environment";

    private static final String[] ADDITIONAL_PATHS_MACOS = { "/opt/homebrew/bin" };

    private static String bestShell = null;

    // https://unix.stackexchange.com/questions/206350/what-is-the-difference-if-i-start-bash-with-bin-bash-or-usr-bin-env-bash
    private static final String[] SHELL_FOLDER = new String[] { "/bin", "/usr/bin", "/usr/local/bin",
            "/usr/local/sbin" };

    // https://www.howtogeek.com/362409/what-is-zsh-and-why-should-you-use-it-instead-of-bash/
    private static final String[] SHELL_PRIORITY = new String[] { "zsh", "bash", "dash", "sh" };

    private static final String[] DEFAULT_UNIX_SOURCE_FILES = new String[] { "/etc/profile", "/etc/bash.bashrc",
            "~/.bashrc", "/etc/zshenv", "~/.zshenv", "/etc/zprofile", "~/.zprofile", "/etc/zshrc", "~/.zshrc",
            "/etc/zlogin", "~/.zlogin", "~/.bash_profile", "~/.bash_login", "~/.profile" };

    private ConsoleCommandExecutor() {
    }

    public static List<String> runConsoleCommandAndCollectResults(String[] command,
            Map<String, String> addtionalEnvironmentVariables) throws IOException, InterruptedException {
        return runConsoleCommandAndCollectResults(command, addtionalEnvironmentVariables, StringUtils.EMPTY, false);
    }

    public static List<String> runConsoleCommandAndCollectResults(String[] command,
            Map<String, String> addtionalEnvironmentVariables, boolean redirectErrorStream) throws IOException, InterruptedException {
        return runConsoleCommandAndCollectResults(command, addtionalEnvironmentVariables, StringUtils.EMPTY, redirectErrorStream);
    }

    public static List<String> runConsoleCommandAndCollectResults(String[] command,
            Map<String, String> addtionalEnvironmentVariables, String directory, boolean redirectErrorStream)
            throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(command);
        if (StringUtils.isNotEmpty(directory)) {
            pb.directory(new File(directory));
        }
        Map<String, String> existingEnvironmentVariables = pb.environment();
        existingEnvironmentVariables.putAll(addtionalEnvironmentVariables);
        pb.redirectErrorStream(redirectErrorStream);

        Process process = pb.start();
        List<String> resultLines = new ArrayList<String>();

        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
        try {
            String line;
            while ((line = br.readLine()) != null) {
                resultLines.add(line);
            }
        } finally {
            if (br != null) {
                br.close();
            }
        }
        process.waitFor();

        return resultLines;
    }

    public static List<String> runConsoleCommandError(String[] command,
            Map<String, String> addtionalEnvironmentVariables, String directory) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(command);
        if (StringUtils.isNotEmpty(directory)) {
            pb.directory(new File(directory));
        }
        Map<String, String> existingEnvironmentVariables = pb.environment();
        existingEnvironmentVariables.putAll(addtionalEnvironmentVariables);

        Process process = pb.start();
        process.waitFor();
        List<String> resultLines = new ArrayList<String>();
        BufferedReader br = new BufferedReader(new InputStreamReader(process.getErrorStream()));
        try {
            String line;
            while ((line = br.readLine()) != null) {
                resultLines.add(line);
            }
        } finally {
            if (br != null) {
                br.close();
            }
        }
        return resultLines;
    }
    
    public static String runConsoleCommandAndCollectFirstResult(String[] command,
            Map<String, String> addtionalEnvironmentVariables,
            String directory) throws IOException, InterruptedException {
        List<String> resultLines = runConsoleCommandAndCollectResults(command, addtionalEnvironmentVariables,
                directory, false);
        if (!resultLines.isEmpty()) {
            return resultLines.get(0);
        }
        return "";
    }

    public static String runConsoleCommandAndCollectFirstResult(String[] command,
            Map<String, String> addtionalEnvironmentVariables) throws IOException, InterruptedException {
        return runConsoleCommandAndCollectFirstResult(command, addtionalEnvironmentVariables, StringUtils.EMPTY);
    }

    public static List<String> runConsoleCommandAndCollectResults(String[] command)
            throws IOException, InterruptedException {
        return runConsoleCommandAndCollectResults(command, new HashMap<String, String>());
    }

    public static String runConsoleCommandAndCollectFirstResult(String[] command)
            throws IOException, InterruptedException {
        List<String> resultLines = runConsoleCommandAndCollectResults(command);
        if (!resultLines.isEmpty()) {
            return resultLines.get(0);
        }
        return "";
    }
    
    public static String runConsoleCommandAndCollectFirstResult(String[] command, boolean redirectErrorStream)
            throws IOException, InterruptedException {
        List<String> resultLines = runConsoleCommandAndCollectResults(command, new HashMap<String, String>(), StringUtils.EMPTY, redirectErrorStream);
        if (!resultLines.isEmpty()) {
            return resultLines.get(0);
        }
        return "";
    }

    public static boolean verifyModuleInstalled(String testCommand) {
        return verifyModuleInstalled(testCommand, null);
    }

    public static boolean verifyModuleInstalled(String testCommand, String signal) {
        String program = StringUtils.contains(testCommand, " ") ? testCommand.split(" ")[0] : testCommand;

        boolean isInstalled = isInstalled(program);
        if (!isInstalled) {
            return false;
        }

        return StringUtils.isEmpty(signal) ? isInstalled : test(testCommand, signal);
    }

    public static boolean isInstalled(String program) {
        return SystemUtils.IS_OS_WINDOWS ? test(program) : isInstalledUnix(program);
    }

    private static boolean isInstalledUnix(String program) {
        try {
            String sourceLoadingCommand = getSourcesLoadingCommand();
            String testCommand = MessageFormat.format("{1}; which \"{0}\" | grep -i \"{0}\"", program,
                    sourceLoadingCommand);
            List<String> result = execSync(testCommand);
            return result.size() > 0 && !result.get(0).contains("not found");
        } catch (IOException | InterruptedException e) {
            return false;
        }
    }

    public static boolean test(String program) {
        return test(program, null);
    }

    public static boolean test(String program, String signal) {
        return SystemUtils.IS_OS_WINDOWS ? windowsTest(program, signal) : unixTest(program, signal);
    }

    private static boolean windowsTest(String program, String signal) {
        try {
            Process process = Runtime.getRuntime().exec(program);
            if (StringUtils.isNotBlank(signal)) {
                List<String> result = ProcessUtil.readSync(process);
                return ProcessUtil.includes(result, signal);
            }
            return true;
        } catch (IOException | InterruptedException e) {
            return false;
        }
    }

    private static boolean unixTest(String program, String signal) {
        try {
            String sourceLoadingCommand = getSourcesLoadingCommand();
            String testCommand = StringUtils.contains(program, " ") ? program
                    : MessageFormat.format("{1}; which \"{0}\"", program, sourceLoadingCommand);
            List<String> result = execSync(testCommand);
            if (StringUtils.isNotBlank(signal)) {
                return ProcessUtil.includes(result, signal);
            }
            return result.size() > 0;
        } catch (IOException | InterruptedException e) {
            return false;
        }
    }
    
    public static String safeWhere(String program) {
        try {
            return where(program);
        } catch (IOException | InterruptedException e) {
            return StringUtils.EMPTY;
        }
    }

    public static String where(String program) throws IOException, InterruptedException {
        String whereCommand = SystemUtils.IS_OS_WINDOWS
                ? MessageFormat.format("where {0}", program)
                : MessageFormat.format("{1}; which {0}", program, getSourcesLoadingCommand());
        List<String> result = execSync(whereCommand, false);
        String firstPath = result.stream().filter((pathI) -> new File(pathI).exists()).findFirst().orElse(null);
        if (StringUtils.isBlank(firstPath)) {
            return StringUtils.EMPTY;
        }
        return new File(firstPath).toPath().toRealPath().toString();
    }

    /**
     * Load all the source files as a terminal do.
     * Only need to use when we're trying to locate the active location of a program.
     * 
     * <ul>
     * References:
     * </ul>
     * <li>https://medium.com/@rajsek/zsh-bash-startup-files-loading-order-bashrc-zshrc-etc-e30045652f2e</li>
     * <li>https://unix.stackexchange.com/questions/71253/what-should-shouldnt-go-in-zshenv-zshrc-zlogin-zprofile-zlogout</li>
     * </ul>
     */
    public static String getSourcesLoadingCommand() {
        final String HOME_DIR = Matcher.quoteReplacement(System.getProperty("user.home") + File.separator);
        String[] defaultSourceCommands = Arrays.stream(DEFAULT_UNIX_SOURCE_FILES)
                .filter((sourceI) -> {
                    String sourcePath = sourceI.replaceFirst("^~[/|\\\\]", HOME_DIR);
                    File sourceFile = new File(sourcePath);
                    return sourceFile.exists() && sourceFile.canRead();
                })
                .map((sourceI) -> MessageFormat.format("source {0} > /dev/null 2>&1", sourceI))
                .collect(Collectors.toList())
                .toArray(new String[] {});
        return StringUtils.join(defaultSourceCommands, "; ");
    }

    public static List<String> execSync(String command) throws IOException, InterruptedException {
        return execSync(command, StringUtils.EMPTY);
    }

    public static List<String> execSync(String command, String workingDir) throws IOException, InterruptedException {
        return execSync(command, workingDir, null);
    }

    public static List<String> execSync(String command, boolean redirectError)
            throws IOException, InterruptedException {
        return execSync(command, redirectError, null);
    }

    public static List<String> execSync(String command, Map<String, String> additionalEnvs)
            throws IOException, InterruptedException {
        return execSync(command, null, additionalEnvs);
    }

    public static List<String> execSync(String command, boolean redirectError, Map<String, String> additionalEnvs)
            throws IOException, InterruptedException {
        return execSync(command, StringUtils.EMPTY, redirectError, additionalEnvs);
    }

    public static List<String> execSync(String command, String workingDir, boolean redirectError)
            throws IOException, InterruptedException {
        return execSync(command, workingDir, redirectError, null);
    }

    public static List<String> execSync(String command, String workingDir, Map<String, String> additionalEnvs)
            throws IOException, InterruptedException {
        return execSync(command, workingDir, true, additionalEnvs);
    }

    public static List<String> execSync(String command, String workingDir, boolean redirectError,
            Map<String, String> additionalEnvs) throws IOException, InterruptedException {
        Process process = exec(command, workingDir, redirectError, additionalEnvs);
        if (process == null) {
            return Collections.emptyList();
        }
        return ProcessUtil.readSync(process);
    }

    public static Process exec(String command) throws IOException {
        return exec(command, StringUtils.EMPTY);
    }

    public static Process exec(String command, String workingDir) throws IOException {
        return exec(command, workingDir, null);
    }

    public static Process exec(String command, boolean redirectError) throws IOException {
        return exec(command, redirectError, null);
    }

    public static Process exec(String command, Map<String, String> additionalEnvs) throws IOException {
        return exec(command, null, additionalEnvs);
    }

    public static Process exec(String command, boolean redirectError, Map<String, String> additionalEnvs)
            throws IOException {
        return exec(command, StringUtils.EMPTY, redirectError, additionalEnvs);
    }

    public static Process exec(String command, String workingDir, boolean redirectError) throws IOException {
        return exec(command, workingDir, redirectError, null);
    }

    public static Process exec(String command, String workingDir, Map<String, String> additionalEnvs)
            throws IOException {
        return exec(command, workingDir, true, additionalEnvs);
    }

    public static Process exec(String command, String workingDir, boolean redirectError,
            Map<String, String> additionalEnvs) throws IOException {
        ProcessBuilder processBuilder = build(command, workingDir, redirectError, additionalEnvs);
        if (processBuilder == null) {
            return null;
        }
        return processBuilder.start();
    }

    public static ProcessBuilder build(String command) {
        return build(command, StringUtils.EMPTY);
    }

    public static ProcessBuilder build(String command, String workingDir) {
        return build(command, workingDir, null);
    }

    public static ProcessBuilder build(String command, boolean redirectError) {
        return build(command, redirectError, null);
    }

    public static ProcessBuilder build(String command, Map<String, String> additionalEnvs) {
        return build(command, null, additionalEnvs);
    }

    public static ProcessBuilder build(String command, boolean redirectError, Map<String, String> additionalEnvs) {
        return build(command, StringUtils.EMPTY, redirectError, null);
    }

    public static ProcessBuilder build(String command, String workingDir, boolean redirectError) {
        return build(command, workingDir, redirectError, null);
    }

    public static ProcessBuilder build(String command, String workingDir, Map<String, String> additionalEnvs) {
        return build(command, workingDir, true, additionalEnvs);
    }

    public static ProcessBuilder build(String command, String workingDir, boolean redirectError,
            Map<String, String> additionalEnvs) {
        if (StringUtils.isBlank(command)) {
            return null;
        }

        String[] commands;
        if (SystemUtils.IS_OS_WINDOWS) {
            String[] windowsCommands = new String[] { "cmd.exe", "/C", command };
            commands = windowsCommands;
        } else {
            // https://stackoverflow.com/questions/15179446/why-does-my-bash-code-fail-when-i-run-it-with-sh
            // https://unix.stackexchange.com/questions/159513/what-are-the-shells-control-and-redirection-operators
            String bestShell = findBestShell();
            if (StringUtils.isBlank(bestShell)) {
                bestShell = "/bin/sh";
            }
            String[] unixLikeCommands = new String[] { bestShell, "-c", command };
            commands = unixLikeCommands;
        }

        ProcessBuilder processBuilder = new ProcessBuilder(commands);
        processBuilder.redirectErrorStream(redirectError);

        Map<String, String> envs = processBuilder.environment();
        envs.putAll(mergeEnvs(envs, additionalEnvs)); // This will also merge envs with the system envs

        if (StringUtils.isNotBlank(workingDir)) {
            processBuilder.directory(new File(workingDir));
        }

        return processBuilder;
    }

    private static String findBestShell() {
        if (StringUtils.isNotBlank(bestShell) && new File(bestShell).exists() && new File(bestShell).canExecute()) {
            return bestShell;
        }
        for (String shellI : SHELL_PRIORITY) {
            for (String shellDirI : SHELL_FOLDER) {
                File shellFile = new File(shellDirI + File.separator + shellI);
                if (shellFile.exists() && shellFile.canExecute()) {
                    bestShell = shellFile.getAbsolutePath();
                    return bestShell;
                }
            }
        }
        return null;
    }

    private static Map<String, String> mergeEnvs(Map<String, String> existingEnvs, Map<String, String> additionalEnvs) {
        if (SystemUtils.IS_OS_MAC) {
            try {
                return mergeMacEnvs(existingEnvs, additionalEnvs);
            } catch (IOException error) {
                // Just skip
            }
        } else if (SystemUtils.IS_OS_LINUX) {
            try {
                return mergeLinuxEnvs(existingEnvs, additionalEnvs);
            } catch (IOException error) {
                // Just skip
            }
        }
        if (additionalEnvs != null) {
            existingEnvs.putAll(additionalEnvs);
        }
        return existingEnvs;
    }

    private static Map<String, String> mergeMacEnvs(Map<String, String> currentEnvs, Map<String, String> additionalEnvs) throws IOException {
        Map<String, String> envs = new HashMap<String, String>();
        envs.putAll(currentEnvs);
        String mergedPath = joinPaths(getMacPathEnvVar(), currentEnvs.get(PATH));
        if (additionalEnvs != null) {
            mergedPath = joinPaths(mergedPath, additionalEnvs.get(PATH));
            envs.putAll(additionalEnvs);
        }
        envs.put(PATH, mergedPath);
        return envs;
    }

    private static String getMacPathEnvVar() throws IOException {
        String systemPath = StringUtils.defaultString(System.getenv(PATH));
        String path = systemPath;

        File pathsFile = new File(MAC_PATH_ENV_FILE);
        if (pathsFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(pathsFile))) {
                for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                    if (StringUtils.isBlank(line)) {
                        continue;
                    }
                    path = joinPaths(path, line.trim());
                }
            }
        }

        for (String pathI : ADDITIONAL_PATHS_MACOS) {
            path = joinPaths(path, pathI);
        }

        return path;
    }

    private static Map<String, String> mergeLinuxEnvs(Map<String, String> currentEnvs,
            Map<String, String> additionalEnvs) throws IOException {
        Map<String, String> envs = new HashMap<String, String>();
        envs.putAll(currentEnvs);
        String mergedPath = joinPaths(getLinuxPathEnvVar(), currentEnvs.get(PATH));
        if (additionalEnvs != null) {
            mergedPath = joinPaths(mergedPath, additionalEnvs.get(PATH));
            envs.putAll(additionalEnvs);
        }
        envs.put(PATH, mergedPath);
        return envs;
    }

    private static String getLinuxPathEnvVar() throws IOException {
        String systemPath = StringUtils.defaultString(System.getenv(PATH));
        String path = systemPath;

        File pathsFile = new File(LINUX_ENV_FILE);
        if (pathsFile.exists()) {
            String pathPrefix = MessageFormat.format("{0}=\"", PATH);
            try (BufferedReader reader = new BufferedReader(new FileReader(pathsFile))) {
                for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                    if (StringUtils.isBlank(line) || !StringUtils.startsWith(line, pathPrefix)) {
                        continue;
                    }
                    line = line.trim();
                    String trimmedPath = line.substring(pathPrefix.length(), line.length() - 1); // PATH="..."
                    path = joinPaths(path, trimmedPath);
                    break;
                }
            }
        }
        return path;
    }

    private static String joinPaths(String... paths) {
        Set<String> distinctPaths = new HashSet<String>();
        Arrays.stream(paths)
                .filter(pathI -> StringUtils.isNotBlank(pathI))
                .forEachOrdered(pathI -> {
                    if (pathI.contains(PATH_SEPARATOR)) {
                        String subPaths[] = pathI.split(PATH_SEPARATOR);
                        distinctPaths.addAll(Arrays.asList(subPaths));
                    } else {
                        distinctPaths.add(pathI);
                    }
                });
        return String.join(PATH_SEPARATOR, distinctPaths);
    }
}
