package com.kms.katalon.core.exception;

public class ActivationException extends Exception {
    private static final long serialVersionUID = -7373897787346634690L;

    public ActivationException(String message) {
        super(message);
    }

    public ActivationException(Throwable cause) {
        super(cause);
    }
}
