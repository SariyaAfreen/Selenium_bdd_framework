package com.kms.katalon.core.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.commons.lang3.StringUtils;

import com.kms.katalon.core.util.internal.JsonUtil;

public class EncodingUtil {
	private EncodingUtil() {
		// Hide the default Constructor
	}

	public static String encodeURIComponent(Object object) {
		String encodeURI = StringUtils.EMPTY;
		try {
			encodeURI = URLEncoder.encode(JsonUtil.toJson(object, false), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return encodeURI;
		}
		return encodeURI;
	}

	public static String encodeURIComponent(String text) {
		String encodeURI = StringUtils.EMPTY;
		try {
			encodeURI = URLEncoder.encode(text, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return encodeURI;
		}
		return encodeURI;
	}
}
