package com.kms.katalon.core.testobject;

public enum ValidationTarget {
    RESPONSE("Response"), REQUEST("Request");

    private String name;

    ValidationTarget(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
