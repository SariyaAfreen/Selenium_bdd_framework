package com.kms.katalon.core.main;

public interface RetrySettings {

    int getCurrentRetryCount();

    int getRemainingRetryCount();
}