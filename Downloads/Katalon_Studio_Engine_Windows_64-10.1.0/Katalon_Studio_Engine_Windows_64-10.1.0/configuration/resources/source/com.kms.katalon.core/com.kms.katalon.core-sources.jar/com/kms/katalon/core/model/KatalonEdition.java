package com.kms.katalon.core.model;

public enum KatalonEdition {
    ENTERPRISE("enterprise"), FREE("free");

    private String name;

    private KatalonEdition(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
