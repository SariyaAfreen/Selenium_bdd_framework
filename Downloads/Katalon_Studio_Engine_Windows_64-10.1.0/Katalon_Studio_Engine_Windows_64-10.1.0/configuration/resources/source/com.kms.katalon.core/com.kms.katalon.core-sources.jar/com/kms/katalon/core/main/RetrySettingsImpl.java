package com.kms.katalon.core.main;

public class RetrySettingsImpl implements RetrySettings {

    private int currentRetryCount;

    private int remainingRetryCount;

    @Override
    public int getCurrentRetryCount() {
        return currentRetryCount;
    }

    public void setCurrentRetryCount(int currentRetryCount) {
        this.currentRetryCount = currentRetryCount;
    }

    @Override
    public int getRemainingRetryCount() {
        return remainingRetryCount;
    }

    public void setRemainingRetryCount(int remainingRetryCount) {
        this.remainingRetryCount = remainingRetryCount;
    }
}
