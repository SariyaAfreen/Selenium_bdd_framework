package com.kms.katalon.core.testobject.authorization;

import java.util.HashMap;
import java.util.Map;

public class BearerAuthorization extends BasicRequestAuthorization {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public static final String BEARER_TOKEN = "bearerToken";
    
    public static final String BEARER = "Bearer";
    
    public BearerAuthorization(String bearerToken) {
        Map<String, String> authorizationInfo = new HashMap<String, String>();
        authorizationInfo.put(BEARER_TOKEN, bearerToken);
        this.setAuthorizationType(BEARER);
        this.setAuthorizationInfo(authorizationInfo);
    }
}
