package com.kms.katalon.core.util;

public class FailedTestThreshold {
    private static FailedTestThreshold _instance;

    private boolean thresholdAvailable = false;

    private int thresholdValue;

    public static FailedTestThreshold getInstance() {
        if (_instance == null) {
            _instance = new FailedTestThreshold();
        }
        return _instance;
    }

    public int getThreshold() {
        return thresholdValue;
    }

    public void setThreshold(int thresholdValue) {
        this.thresholdValue = thresholdValue;
    }

    public void setThresholdAvailable(boolean thresholdAvailable) {
        this.thresholdAvailable = thresholdAvailable;
    }

    public boolean isThresholdAvailable() {
        return thresholdAvailable;
    }
}
