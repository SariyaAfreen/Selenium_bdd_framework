package com.kms.katalon.core.constants;

public class CoreConstants {
    public static final Boolean DEFAULT_LOG_TEST_STEPS = true;

    public static final Boolean DEFAULT_HIDE_HOST_NAME = false;

    public static final String PLATFORM_WEB = "web";

    public static final String PLATFORM_MOBILE = "mobile";

    public static final String PLATFORM_WEB_SERVICE = "webservice";
    
    public static final String PLATFORM_WINDOWS = "windows";

    public static final String PLATFORM_BUILT_IN = "builtin";
    
    public static final String PLATFORM_APPLITOOLS = "applitools";

    public static final String TEST_CASE_CURRENT_RETRY_COUNT = "currentRetryCount";

    public static final String TEST_CASE_REMAINING_RETRY_COUNT = "remainingRetryCount";
    
    public static final String KATONE_API_SERVER = "https://api.katalon.com";
            
    public static final String KATONE_SERVER_PROP = "katOneServerUrl";
    
    public static final String ADMIN_API_SERVER = "https://admin.katalon.com";
    
    public static final String ADMIN_SERVER_PROP = "adminServerUrl";
    
    public static final String KEYCLOAK_API_SERVER = "https://login.katalon.com";
    
    public static final String KEYCLOAK_SERVER_PROP = "loginServerUrl";
    
    public static final String KEYCLOAK_TOKEN_PART = "/realms/katalon/protocol/openid-connect/token";

    public static final String KEYCLOAK_LOGOUT_PART = "/realms/katalon/protocol/openid-connect/logout";
}
