package com.kms.katalon.core.testobject.authorization;

import java.util.Map;

public interface RequestAuthorization {

    public String getAuthorizationType();
    
    public void setAuthorizationType(String authorizationType);
    
    public Map<String, String> getAuthorizationInfo();
    
    public void setAuthorizationInfo(Map<String, String> authorizationInfo);
}
