package com.kms.katalon.core.util;

import com.kms.katalon.core.model.KatalonEdition;

public class ApplicationEdition {
    private static KatalonEdition edition;
    
    //This should be called only  once in application startup
    public static void set(KatalonEdition edition) {
        ApplicationEdition.edition = edition;
    }
    
    public static KatalonEdition get() {
        return edition;
    }
    
    public static boolean isFreeEdition() {
        return KatalonEdition.FREE == edition;
    }
    
    public static KatalonEdition getOrElse(KatalonEdition defaultEdition) {
        return edition != null ? edition : defaultEdition;
    }
}
