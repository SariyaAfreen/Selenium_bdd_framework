package com.kms.katalon.core.setting;

import com.kms.katalon.core.model.TakeScreenshotOption;

public class TakeScreenshotSettings {
    private boolean enable;

    private TakeScreenshotOption takeScreenshotOption;

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public TakeScreenshotOption getTakeScreenshotOption() {
        return takeScreenshotOption;
    }

    public void setTakeScreenshotOption(TakeScreenshotOption takeScreenshotOption) {
        this.takeScreenshotOption = takeScreenshotOption;
    }

    public boolean isTakeScreenshotEveryTestSteps() {
        return TakeScreenshotOption.ALL_STEPS == takeScreenshotOption;
    }
}
