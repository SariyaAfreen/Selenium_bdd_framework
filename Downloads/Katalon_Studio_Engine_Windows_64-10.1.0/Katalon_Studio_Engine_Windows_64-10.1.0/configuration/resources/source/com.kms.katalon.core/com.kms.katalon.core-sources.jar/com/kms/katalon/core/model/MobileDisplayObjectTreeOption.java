package com.kms.katalon.core.model;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum MobileDisplayObjectTreeOption {
    // Minimal is the default option
    Full, Minimal;

    public static String[] valueStrings() {
        List<String> values = Arrays.stream(values()).map(str -> str.name()).collect(Collectors.toList());
        return values.toArray(new String[0]);
    }
}
