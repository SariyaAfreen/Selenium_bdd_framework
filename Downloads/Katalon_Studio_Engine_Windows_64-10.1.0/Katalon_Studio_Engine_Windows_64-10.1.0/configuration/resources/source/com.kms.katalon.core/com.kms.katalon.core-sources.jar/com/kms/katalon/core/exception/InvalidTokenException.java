package com.kms.katalon.core.exception;

public class InvalidTokenException extends Exception {

	private static final long serialVersionUID = -1049131180700738830L;

	public InvalidTokenException(Throwable e) {
        super(e);
    }

    public InvalidTokenException(String message) {
        super(message);
    }

    public static InvalidTokenException wrap(Exception exception) {
        if (exception instanceof InvalidTokenException) {
            return (InvalidTokenException) exception;
        } else {
            return new InvalidTokenException(exception);
        }
    }
}
