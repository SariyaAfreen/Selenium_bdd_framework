package com.kms.katalon.core.mobile.keyword.builtin

import java.text.MessageFormat
import java.time.Duration

import org.apache.commons.io.FileUtils
import org.openqa.selenium.Point
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.internal.Action
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.keyword.internal.SupportLevel
import com.kms.katalon.core.mobile.helper.MobileCommonHelper
import com.kms.katalon.core.mobile.keyword.internal.MobileAbstractKeyword
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.mobile.keyword.internal.MobileKeywordMain
import com.kms.katalon.core.model.FailureHandling

import groovy.transform.CompileStatic
import io.appium.java_client.AppiumBy
import io.appium.java_client.AppiumDriver
import io.appium.java_client.touch.WaitOptions
import io.appium.java_client.touch.offset.PointOption

@Action(value = "tapOnImage")
public class TapOnImageKeyword extends MobileAbstractKeyword {

    @CompileStatic
    @Override
    public SupportLevel getSupportLevel(Object ...params) {
        return super.getSupportLevel(params)
    }

    @CompileStatic
    @Override
    public Object execute(Object ...params) {
        String imageFilePath = (String) params[0]
        FailureHandling flowControl = (FailureHandling)(params.length > 1 && params[1] instanceof FailureHandling ? params[1] : RunConfiguration.getDefaultFailureHandling())
        tapOnImage(imageFilePath, flowControl)
    }

    @CompileStatic
    public void tapOnImage(String imageFilePath, FailureHandling flowControl) throws StepFailedException {
        MobileKeywordMain.runKeyword({
            AppiumDriver driver = MobileDriverFactory.getDriver()

            byte[] fileContent = FileUtils.readFileToByteArray(new File(imageFilePath))

            String encodedString = Base64.getEncoder().encodeToString(fileContent)

            List elements = driver.findElements(AppiumBy.image(encodedString))
            logger.logInfo(MessageFormat.format("Found {0} element(s) on screen", elements.size()))
            if (elements.isEmpty()) {
                throw new StepFailedException("No image element found")
            }
            
            WebElement element = elements.get(0)
            Point location = element.getLocation()

            logger.logInfo(MessageFormat.format("Tap on image at location ({0}, {1})", location.x, location.y))
            MobileCommonHelper.tap(driver, element.getLocation(), Duration.ofMillis(50))

            logger.logPassed(MessageFormat.format("Tap on image ''{0}'' at location ({1}, {2}) successfully", imageFilePath, location.x, location.y))
        }, flowControl, RunConfiguration.getTakeScreenshotOption(), "Failed to tap on image")
    }
}
