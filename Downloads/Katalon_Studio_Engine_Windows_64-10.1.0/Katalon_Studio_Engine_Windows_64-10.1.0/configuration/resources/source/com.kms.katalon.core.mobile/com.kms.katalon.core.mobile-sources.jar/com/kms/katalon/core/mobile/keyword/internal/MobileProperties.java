package com.kms.katalon.core.mobile.keyword.internal;

public class MobileProperties {
    public static final String NAME = "name";

    public static final String XPATH = "xpath";
}
