package com.kms.katalon.core.mobile.driver;

import java.util.HashMap;
import java.util.Map;

import io.appium.java_client.AppiumDriver;

public class AppiumDriverSession {
    
    private AppiumDriver driver;
    private Map<String, Object> properties;
    public AppiumDriver getDriver() {
        return driver;
    }
    public void setDriver(AppiumDriver driver) {
        this.driver = driver;
    }
    public Map<String, Object> getProperties() {
        return properties;
    }
    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }
    
    public AppiumDriverSession(AppiumDriver driver) {
        this.driver = driver;
        properties = new HashMap<>();
    }
    
}
