package com.kms.katalon.core.webservice.common;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.kms.katalon.logging.LogUtil;

public class SimpleErrorHandler implements ErrorHandler{

    @Override
    public void warning(SAXParseException exception) throws SAXException {
        LogUtil.printErrorLine(exception.getMessage());
        throw exception;
    }

    @Override
    public void error(SAXParseException exception) throws SAXException {
        LogUtil.printErrorLine(exception.getMessage());
        throw exception;        
    }

    @Override
    public void fatalError(SAXParseException exception) throws SAXException {
        LogUtil.printErrorLine(exception.getMessage());
        throw exception;        
    }

}
