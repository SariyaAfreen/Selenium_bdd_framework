package com.kms.katalon.core.webservice.keyword.builtin;
import com.kms.katalon.core.annotation.internal.Action
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.keyword.internal.KeywordMain
import com.kms.katalon.core.keyword.internal.SupportLevel
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.webservice.constants.StringConstants
import com.kms.katalon.core.webservice.keyword.internal.WebserviceAbstractKeyword

import groovy.transform.CompileStatic

@Action(value = 'getHarFileGeneration')
public class GetHarFileGenerationKeyword extends WebserviceAbstractKeyword {

    @CompileStatic
    @Override
    public SupportLevel getSupportLevel(Object ...params) {
        return super.getSupportLevel(params)
    }

    @Override
    public Object execute(Object... params) {
        FailureHandling flowControl = (FailureHandling)(params.length > 0 && params[0] instanceof FailureHandling ? params[0] : RunConfiguration.getDefaultFailureHandling())
        getHarFileGeneration(flowControl);
    }

    @CompileStatic
    public boolean getHarFileGeneration(FailureHandling flowControl) throws StepFailedException{
        return KeywordMain.runKeyword({
            return RunConfiguration.getHarFileGeneration()
        },flowControl,StringConstants.KW_LOG_FAILED_GET_HAR_FILE_GENERATION)
    }
}
