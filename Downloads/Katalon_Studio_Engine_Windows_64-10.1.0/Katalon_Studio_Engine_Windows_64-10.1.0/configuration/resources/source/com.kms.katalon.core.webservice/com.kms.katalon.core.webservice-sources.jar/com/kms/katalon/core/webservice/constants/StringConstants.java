package com.kms.katalon.core.webservice.constants;

import com.kms.katalon.core.annotation.Keyword;

public class StringConstants {
	// WebServiceKeywordContributor
    public static final String CONTR_LBL_WEB_SERVICE_KEYWORD = "Web Service Keyword";

	// WSBuiltInKeywords
    public static final String KW_LOG_FAILED_ELEMENT_COUNT_NOT_EQUAL = CoreWebserviceMessageConstants.KW_LOG_FAILED_ELEMENT_COUNT_NOT_EQUAL;
    public static final String KW_LOG_FAILED_ELEMENT_PROP_VAL_NOT_EQUAL = CoreWebserviceMessageConstants.KW_LOG_FAILED_ELEMENT_PROP_VAL_NOT_EQUAL;
    public static final String KW_LOG_FAILED_ACTUAL_ELEMENT_TEXT_IS = CoreWebserviceMessageConstants.KW_LOG_FAILED_ACTUAL_ELEMENT_TEXT_IS;
    public static final String KW_STR_NOT_FOUND_IN_RES = CoreWebserviceMessageConstants.KW_STR_NOT_FOUND_IN_RES;
    public static final String KW_LOG_FAILED_CANNOT_SEND_REQUEST = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_SEND_REQUEST;
    public static final String KW_LOG_FAILED_CANNOT_SEND_REQUEST_AND_VERIFY = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_SEND_REQUEST_AND_VERIFY;
    public static final String KW_LOG_PASSED_SEND_REQUEST_SUCCESS = CoreWebserviceMessageConstants.KW_LOG_PASSED_SEND_REQUEST_SUCCESS;
    public static final String KW_LOG_PASSED_SEND_REQUEST_AND_VERIFY_SUCCESS = CoreWebserviceMessageConstants.KW_LOG_PASSED_SEND_REQUEST_AND_VERIFY_SUCCESS;
    public static final String KW_LOG_FAILED_CANNOT_VERIFY_ELEMENT_COUNT = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_VERIFY_ELEMENT_COUNT;
    public static final String KW_LOG_FAILED_CANNOT_GET_ELEMENT_COUNT = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_GET_ELEMENT_COUNT;
    public static final String KW_LOG_PASSED_VERIFY_ELEMENT_COUNT = CoreWebserviceMessageConstants.KW_LOG_PASSED_VERIFY_ELEMENT_COUNT;
    public static final String KW_LOG_FAILED_CANNOT_VERIFY_ELEMENT_PROPERTY_VALUE = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_VERIFY_ELEMENT_PROPERTY_VALUE;
    public static final String KW_LOG_FAILED_CANNOT_GET_ELEMENT_PROPERTY_VALUE = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_GET_ELEMENT_PROPERTY_VALUE;
    public static final String KW_LOG_PASSED_VERIFY_ELEMENT_PROPERTY_VALUE = CoreWebserviceMessageConstants.KW_LOG_PASSED_VERIFY_ELEMENT_PROPERTY_VALUE;
    public static final String KW_LOG_FAILED_CANNOT_VERIFY_ELEMENT_TEXT = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_VERIFY_ELEMENT_TEXT;
    public static final String KW_LOG_FAILED_CANNOT_GET_ELEMENT_TEXT = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_GET_ELEMENT_TEXT;
    public static final String KW_LOG_PASSED_VERIFY_ELEMENT_TEXT = CoreWebserviceMessageConstants.KW_LOG_PASSED_VERIFY_ELEMENT_TEXT;
    public static final String KW_LOG_PASSED_CONTAIN_STRING = CoreWebserviceMessageConstants.KW_LOG_PASSED_CONTAIN_STRING;
    public static final String KW_LOG_FAILED_CONTAIN_STRING = CoreWebserviceMessageConstants.KW_LOG_FAILED_CONTAIN_STRING;
	public static final String KW_LOG_FAILED_CANNOT_GET_RESPONSE_STATUS_CODE = CoreWebserviceMessageConstants.KW_LOG_FAILED_CANNOT_GET_RESPONSE_STATUS_CODE;
	public static final String KW_LOG_FAILED_GET_HAR_FILE_GENERATION = CoreWebserviceMessageConstants.KW_LOG_FAILED_GET_HAR_FILE_GENERATION;
	public static final String KW_LOG_FAILED_SET_HAR_FILE_GENERATION = CoreWebserviceMessageConstants.KW_LOG_FAILED_SET_HAR_FILE_GENERATION;
	public static final String KW_LOG_PASSED_SET_HAR_FILE_GENERATION = CoreWebserviceMessageConstants.KW_LOG_PASSED_SET_HAR_FILE_GENERATION;
	public static final String KW_LOG_VALIDATION_STEP_FAILED = CoreWebserviceMessageConstants.KW_LOG_VALIDATION_STEP_FAILED;
	public static final String KW_LOG_VALIDATION_STEP_FAILED_BECAUSE_OF_ERROR = CoreWebserviceMessageConstants.KW_LOG_VALIDATION_STEP_FAILED_BECAUSE_OF_ERROR;
	public static final String KW_LOG_VALIDATION_STEP_PASSED = CoreWebserviceMessageConstants.KW_LOG_VALIDATION_STEP_PASSED;
    public static final String KW_CATEGORIZE_ELEMENT = "Element";
    public static final String KW_CATEGORIZE_REQUEST = "Request";
    public static final String KW_CATEGORIZE_TEXT = "Text";
	public static final String KW_CATEGORIZE_UTILITIES = "Utilities";
	
	// WebServiceCommonHelper
    public static final String KW_LOG_INFO_CHECKING_REQUEST_OBJECT = CoreWebserviceMessageConstants.KW_LOG_INFO_CHECKING_REQUEST_OBJECT;
    public static final String KW_LOG_INFO_CHECKING_REQUEST_BODY_OBJECT = CoreWebserviceMessageConstants.KW_LOG_INFO_CHECKING_REQUEST_OBJECT_BODY;
    public static final String KW_LOG_FAILED_REQUEST_OBJECT_IS_NULL = CoreWebserviceMessageConstants.KW_LOG_FAILED_REQUEST_OBJECT_IS_NULL;
    public static final String KW_LOG_INFO_CHECKING_RESPONSE_OBJECT = CoreWebserviceMessageConstants.KW_LOG_INFO_CHECKING_RESPONSE_OBJECT;
    public static final String KW_LOG_INFO_CHECKING_RESPONSE_OBJECT_CONTENT = CoreWebserviceMessageConstants.KW_LOG_INFO_CHECKING_RESPONSE_OBJECT_CONTENT;
    public static final String KW_LOG_FAILED_RESPONSE_OBJECT_IS_NULL = CoreWebserviceMessageConstants.KW_LOG_FAILED_RESPONSE_OBJECT_IS_NULL;
    public static final String KW_LOG_FAILED_RESPONSE_OBJECT_BODY_IS_NULL = CoreWebserviceMessageConstants.KW_LOG_FAILED_REQUEST_OBJECT_BODY_IS_NULL;
    public static final String KW_LOG_FAILED_RESPONSE_OBJECT_CONTENT_IS_NULL = CoreWebserviceMessageConstants.KW_LOG_FAILED_RESPONSE_OBJECT_CONTENT_IS_NULL;
    
    public static final String MSG_NO_SERVICE_OPERATION = CoreWebserviceMessageConstants.MSG_NO_SERVICE_OPERATION;

    // WebServiceSettingStore
    public static final String WEBSERVICE_BUNDLE_ID = "com.kms.katalon.core.webservice";

    public static final String SETTING_SSL_CERTIFICATE = "network.sslCert";
    
    public static final String WEBSERVICE_METHODS = "webServiceMethods";
    
    public static final String SETTING_SSL_CLIENT_CERTIFICATE = "network.sslClientCert";
    
    public static final String SETTINGS_KEYSTORE = "network.keyStore";
    
    public static final String SETTINGS_KEYSTORE_PW = "network.keyStorePassword";
    
    public static final String KW_LOG_INFO_VERIFICATION_START = CoreWebserviceMessageConstants.KW_LOG_INFO_VERIFICATION_START;
    
    public static final String KW_LOG_INFO_VALIDATION_START = CoreWebserviceMessageConstants.KW_LOG_INFO_VALIDATION_START;
    
    public static final String KW_LOG_VERIFICATION_STEP_FAILED = CoreWebserviceMessageConstants.KW_LOG_VERIFICATION_STEP_FAILED;

    public static final String KW_LOG_VERIFICATION_STEP_FAILED_BECAUSE_OF_ERROR = CoreWebserviceMessageConstants.KW_LOG_VERIFICATION_STEP_FAILED_BECAUSE_OF_ERROR;
    
    public static final String KW_LOG_VERIFICATION_STEP_PASSED = CoreWebserviceMessageConstants.KW_LOG_VERIFICATION_STEP_PASSED;
    
    // Exception Messages
    public static final String MSG_CONNECTION_TIMEOUT_EXCEPTION = CoreWebserviceMessageConstants.MSG_CONNECTION_TIMEOUT_EXCEPTION;

    public static final String MSG_SOCKET_TIMEOUT_EXCEPTION = CoreWebserviceMessageConstants.MSG_SOCKET_TIMEOUT_EXCEPTION;

    public static final String MSG_RESPONSE_SIZE_LIMIT_EXCEPTION = CoreWebserviceMessageConstants.MSG_RESPONSE_SIZE_LIMIT_EXCEPTION;
}
