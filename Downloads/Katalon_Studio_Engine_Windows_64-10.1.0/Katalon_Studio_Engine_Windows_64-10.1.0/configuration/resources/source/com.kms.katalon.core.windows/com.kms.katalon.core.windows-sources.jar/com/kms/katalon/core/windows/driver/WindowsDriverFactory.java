package com.kms.katalon.core.windows.driver;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.http.HttpClient.Factory;

import com.kms.katalon.core.configuration.RunConfiguration;
import com.kms.katalon.core.logging.KeywordLogger;
import com.kms.katalon.core.network.ProxyInformation;
import com.kms.katalon.core.selenium.remote.http.ConfiguredHttpClientFactory;
import com.kms.katalon.core.util.internal.JsonUtil;
import com.kms.katalon.core.windows.constants.WindowsDriverConstants;
import com.kms.katalon.core.windows.keyword.helper.WindowsActionHelper;
import com.kms.katalon.core.windows.keyword.helper.WindowsShortcut;
import com.kms.katalon.core.windows.model.StringMatchingStrategy;

import io.appium.java_client.MobileCommand;
import io.appium.java_client.remote.AppiumCommandExecutor;
import io.appium.java_client.windows.WindowsDriver;

public class WindowsDriverFactory {

    private static final int DEFAULT_CONNECT_TIMEOUT_IN_SECONDS = 120;

    private static final int DEFAULT_READ_TIMEOUT_IN_SECONDS = 10800;

    private static final int DEFAULT_WRITE_TIMEOUT_IN_SECONDS = 0;

    private static KeywordLogger logger = KeywordLogger.getInstance(WindowsDriverFactory.class);

    public static final String DESIRED_CAPABILITIES_PROPERTY = "desiredCapabilities";

    public static final String WIN_APP_DRIVER_PROPERTY = "winAppDriverUrl";

    public static final String CAPS_APP_WORKING_DIR = "appWorkingDir";

    public static final String CAPS_APP_ARGS = "appArguments";

    private static WindowsSession windowsSession;

    public static WindowsDriver getWindowsDriver() {
        return windowsSession.getRunningDriver();
    }

    public static WindowsSession getWindowsSession() {
        return windowsSession;
    }

    public static WindowsDriver startApplication(String appFile, String appTitle)
            throws IOException, URISyntaxException, InterruptedException {
        return startApplication(appFile, appTitle, null);
    }

    @SuppressWarnings("unchecked")
    public static WindowsDriver startApplication(String appFile, String appTitle,
            StringMatchingStrategy strategy)
            throws IOException, URISyntaxException, InterruptedException {
        Map<String, Object> userConfigProperties = RunConfiguration.getDriverPreferencesProperties("Windows");
        if (userConfigProperties == null) {
            userConfigProperties = new HashMap<String, Object>();
        }

        String remoteAddressURLAsString = (String) userConfigProperties.getOrDefault(WIN_APP_DRIVER_PROPERTY,
                WindowsDriverConstants.DEFAULT_WIN_APP_DRIVER_URL);
        URL remoteAddressURL = new URL(remoteAddressURLAsString);
        if (!remoteAddressURLAsString.equals(WindowsDriverConstants.DEFAULT_WIN_APP_DRIVER_URL)) {
            logger.logInfo(String.format("Starting application %s on the test machine at address %s", appFile,
                    remoteAddressURL.toString()));
            logger.logRunData(WIN_APP_DRIVER_PROPERTY, remoteAddressURL.toString());
        } else {
            logger.logInfo(String.format("Starting application %s on the local machine at address %s", appFile,
                    remoteAddressURL.toString()));
        }

        Object desiredCapabilitiesAsObject = userConfigProperties.getOrDefault(DESIRED_CAPABILITIES_PROPERTY, null);
        DesiredCapabilities desiredCapabilities = (desiredCapabilitiesAsObject instanceof Map)
                ? new DesiredCapabilities((Map<String, Object>) desiredCapabilitiesAsObject)
                : new DesiredCapabilities();
        logger.logRunData(DESIRED_CAPABILITIES_PROPERTY, JsonUtil.toJson(desiredCapabilities.toJson(), false));

        ProxyInformation proxyInfo = RunConfiguration.getProxyInformation();
        WindowsDriver windowsDriver = startApplication(remoteAddressURL, appFile, desiredCapabilities,
                proxyInfo, appTitle, strategy).getRunningDriver();

        windowsDriver.manage().timeouts().implicitlyWait(RunConfiguration.getTimeOut(), TimeUnit.SECONDS);
        
        return windowsDriver;

    }

    public static WindowsSession startApplication(URL remoteAddressURL, String appFile,
            DesiredCapabilities initCapabilities, ProxyInformation proxyInfo, String appTitle,
            StringMatchingStrategy strategy)
            throws IOException, URISyntaxException, InterruptedException {
        try {
            if (WindowsShortcut.isShortcutFilePath(appFile)) {
                try {
                    WindowsShortcut shortcut = WindowsShortcut.from(appFile);
                    appFile = shortcut.getRealFilename();
                    setDefaultDesiredCapability(initCapabilities, CAPS_APP_ARGS, shortcut.getCommandLineArguments());
                    setDefaultDesiredCapability(initCapabilities, CAPS_APP_WORKING_DIR, shortcut.getWorkingDirectory());
                } catch (IOException | ParseException error) {
                    logger.logWarning(MessageFormat.format("Failed to read the shortcut file \"{0}\": {1}", appFile,
                            error.getMessage()));
                }
            }

            try {
                setDefaultDesiredCapability(initCapabilities, CAPS_APP_WORKING_DIR,
                        new File(appFile).getParentFile().getCanonicalPath());
            } catch (Throwable error) {
                // Ignore
            }

            windowsSession = new WindowsSession(remoteAddressURL, appFile, initCapabilities, proxyInfo);

            DesiredCapabilities desiredCapabilities = new DesiredCapabilities(initCapabilities);
            desiredCapabilities.setCapability("app", appFile);
            WindowsDriver windowsDriver = newWindowsDriver(remoteAddressURL, desiredCapabilities, proxyInfo);
            windowsDriver.getWindowHandle();

            windowsSession.setApplicationDriver(windowsDriver);

            if (StringUtils.isNotEmpty(appTitle)) {
                switchToWindowTitle(appTitle, strategy);
            }

            return windowsSession;
        } catch (WebDriverException e) {
            if (StringUtils.isEmpty(appTitle)) {
                throw e;
            }
            if (!(e instanceof NoSuchWindowException) && !(e instanceof SessionNotCreatedException)) {
                throw e;
            }
            if (e.getMessage() != null && e.getMessage().contains("The system cannot find the file specified")) {
                // appFile is not correct
                throw e;
            }
            if ("Root".equals(appFile)) {
                throw e;
            }

            WindowsDriver foundDriver = switchToWindowTitle(appTitle, strategy);
            if (foundDriver != null) {
                return windowsSession;
            }

            throw e;
        }
    }

    public static WindowsDriver switchToWindowTitle(String title, StringMatchingStrategy strategy)
            throws IOException, URISyntaxException, InterruptedException {
        return new WindowsActionHelper(windowsSession).switchToWindowTitle(title, strategy);
    }

    public static WindowsDriver newWindowsDriver(URL remoteAddressURL,
            DesiredCapabilities desiredCapabilities, ProxyInformation proxyInfo) throws IOException, URISyntaxException {
        if (remoteAddressURL != null) {
            return new WindowsDriver(getAppiumExecutorForRemoteDriver(remoteAddressURL, proxyInfo),
                    desiredCapabilities);
        } else {
            return new WindowsDriver(desiredCapabilities);
        }
    }

    public static AppiumCommandExecutor getAppiumExecutorForRemoteDriver(URL remoteWebServerUrl, ProxyInformation proxyInfo)
            throws IOException, URISyntaxException {
        Factory clientFactory = ConfiguredHttpClientFactory.of(proxyInfo, remoteWebServerUrl);
        AppiumCommandExecutor executor = new AppiumCommandExecutor(MobileCommand.commandRepository, remoteWebServerUrl,
                clientFactory);
        return executor;
    }

    protected static void setDefaultDesiredCapability(DesiredCapabilities caps, String key, Object value) {
        if (caps.getCapability(key) != null) {
            return;
        }
        caps.setCapability(key, value);
    }
}
