package com.kms.katalon.core.windows.model;

public enum StringMatchingStrategy {
	EXACT,
	CONTAINS,
	REGEXP
}
